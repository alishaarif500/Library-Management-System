// Automated test suite for the Library Management System.
// Self-contained (no framework). Build with the project and run: it prints PASS/FAIL for every
// check and a final summary. Exit code is 0 only if every check passed.
// All tests use a temporary directory, so real or sample data is never touched.

#include <chrono>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

#include "ConsoleUI.h"
#include "DateUtils.h"
#include "FileManager.h"
#include "InputValidator.h"
#include "Library.h"
#include "ReportManager.h"

// Project folder used to find data/sample_*.csv. CMake sets it; otherwise tests must be run from the project root.
#ifndef TEST_PROJECT_ROOT
#define TEST_PROJECT_ROOT "."
#endif

namespace fs = std::filesystem;

namespace {

int g_passed = 0;
int g_failed = 0;
std::string g_currentGroup;

void check(bool condition, const std::string& name) {
    if (condition) { ++g_passed; std::cout << "  [PASS] " << name << "\n"; }
    else { ++g_failed; std::cout << "  [FAIL] " << g_currentGroup << ": " << name << "\n"; }
}

// Runs `f` and returns true if it throws an exception of type E.
template <typename E, typename F>
bool throwsError(F&& f) {
    try { f(); } catch (const E&) { return true; } catch (...) { return false; }
    return false;
}

// Temporary directory removed automatically (RAII).
class TempDir {
public:
    TempDir() {
        static int counter = 0;
        const auto stamp = std::chrono::steady_clock::now().time_since_epoch().count();
        path_ = fs::temp_directory_path() / ("lms_test_" + std::to_string(stamp) + "_" + std::to_string(counter++));
        fs::create_directories(path_);
    }
    ~TempDir() { std::error_code ec; fs::remove_all(path_, ec); }
    std::string str() const { return path_.string(); }
    std::string file(const std::string& name) const { return (path_ / name).string(); }
private:
    fs::path path_;
};

void writeText(const std::string& path, const std::string& text) {
    std::ofstream f(path, std::ios::binary);
    f << text;
}
std::string readText(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    std::stringstream ss;
    ss << f.rdbuf();
    return ss.str();
}

BookData sampleBook(const std::string& isbn = "978-0-13-235088-4", const std::string& title = "Clean Code",
                    int copies = 3) {
    BookData d;
    d.isbn = isbn; d.title = title; d.author = "Robert C. Martin"; d.publisher = "Prentice Hall";
    d.category = "Software"; d.year = 2008; d.totalCopies = copies;
    return d;
}
MemberData sampleMember(const std::string& name = "Ayesha Khan", const std::string& email = "ayesha@example.com") {
    MemberData d;
    d.name = name; d.phone = "+92 300 1234567"; d.email = email;
    return d;
}

// ---------------------------------------------------------------------------------------------
void testDateUtils() {
    g_currentGroup = "DateUtils";
    std::cout << "\n== DateUtils ==\n";
    check(DateUtils::isValidDate("2024-02-29"), "leap day 2024-02-29 is valid");
    check(!DateUtils::isValidDate("2023-02-29"), "2023-02-29 is invalid");
    check(!DateUtils::isValidDate("1900-02-29"), "1900 is not a leap year");
    check(DateUtils::isValidDate("2000-02-29"), "2000 is a leap year");
    check(!DateUtils::isValidDate("2024-13-01"), "month 13 is invalid");
    check(!DateUtils::isValidDate("2024-00-10"), "month 0 is invalid");
    check(!DateUtils::isValidDate("2024-04-31"), "April 31 is invalid");
    check(!DateUtils::isValidDate("2024/04/10"), "wrong separator is invalid");
    check(!DateUtils::isValidDate("24-04-10"), "short year is invalid");
    check(!DateUtils::isValidDate(""), "empty date is invalid");
    check(!DateUtils::isValidDate("abcd-ef-gh"), "letters are invalid");
    check(DateUtils::addDays("2024-01-31", 1) == "2024-02-01", "addDays crosses month end");
    check(DateUtils::addDays("2023-12-31", 1) == "2024-01-01", "addDays crosses year end");
    check(DateUtils::addDays("2024-02-28", 1) == "2024-02-29", "addDays into leap day");
    check(DateUtils::addDays("2024-03-01", -1) == "2024-02-29", "addDays negative");
    check(DateUtils::daysBetween("2024-01-01", "2024-01-15") == 14, "daysBetween 14");
    check(DateUtils::daysBetween("2024-01-15", "2024-01-01") == -14, "daysBetween negative");
    check(DateUtils::daysBetween("2023-01-01", "2024-01-01") == 365, "daysBetween one year");
    check(DateUtils::daysBetween("2024-01-01", "2025-01-01") == 366, "daysBetween leap year");
    check(throwsError<std::invalid_argument>([] { DateUtils::toDayNumber("2024-99-99"); }), "toDayNumber rejects bad date");
    check(DateUtils::isValidDate(DateUtils::today()), "today() returns a valid date");
}

void testValidators() {
    g_currentGroup = "InputValidator";
    std::cout << "\n== InputValidator (pure functions) ==\n";
    using namespace InputValidator;
    long long v = 0;
    check(tryParseInt("42", v) && v == 42, "parse '42'");
    check(tryParseInt("  -7 ", v) && v == -7, "parse ' -7 ' with spaces");
    check(!tryParseInt("abc", v), "reject letters");
    check(!tryParseInt("12abc", v), "reject trailing letters");
    check(!tryParseInt("", v), "reject empty");
    check(!tryParseInt("-", v), "reject lone minus");
    check(!tryParseInt("99999999999999999999999", v), "reject overflow-sized number");
    check(!tryParseInt("1.5", v), "reject decimal as integer");
    long long c = 0;
    check(tryParseMoney("0.50", c) && c == 50, "money 0.50 -> 50");
    check(tryParseMoney("2", c) && c == 200, "money 2 -> 200");
    check(tryParseMoney("2.5", c) && c == 250, "money 2.5 -> 250");
    check(tryParseMoney(".25", c) && c == 25, "money .25 -> 25");
    check(!tryParseMoney("1.234", c), "money rejects 3 decimals");
    check(!tryParseMoney("-1", c), "money rejects negative");
    check(!tryParseMoney("abc", c), "money rejects text");
    check(!tryParseMoney(".", c), "money rejects lone dot");
    check(isValidEmail("a.b@example.com"), "valid email");
    check(!isValidEmail("a@b"), "email without dot in domain");
    check(!isValidEmail("@example.com"), "email without local part");
    check(!isValidEmail("a b@example.com"), "email with space");
    check(!isValidEmail("a@@example.com"), "email with two @");
    check(!isValidEmail("plainaddress"), "email without @");
    check(isValidPhone("+92 300 1234567"), "valid phone with +");
    check(isValidPhone("0301-7654321"), "valid phone with dash");
    check(!isValidPhone("12345"), "too-short phone");
    check(!isValidPhone("abc1234567"), "phone with letters");
    check(!isValidPhone("1234567890123456"), "too-long phone");
    check(normalizeIsbn("978-0-13-235088-4") == "9780132350884", "ISBN-13 normalised");
    check(normalizeIsbn("0-306-40615-2") == "0306406152", "ISBN-10 normalised");
    check(normalizeIsbn("080442957x") == "080442957X", "ISBN-10 with x check digit");
    check(normalizeIsbn("12345").empty(), "short ISBN rejected");
    check(normalizeIsbn("97801323508XX").empty(), "ISBN-13 with letters rejected");
    check(isValidRequiredText("Valid text"), "required text accepts normal text");
    check(!isValidRequiredText("   "), "required text rejects blanks");
    check(!isValidRequiredText(std::string(101, 'a')), "required text rejects 101 chars");
    check(isValidRequiredText(std::string(100, 'a')), "required text accepts 100 chars");
    check(!isValidRequiredText("bad\tchar"), "required text rejects control characters");
    check(isValidRequiredText("O'Brien, \"Mac\" & Sons"), "required text accepts quotes/commas/ampersand");
}

void testInteractiveInput() {
    g_currentGroup = "InputValidator (interactive)";
    std::cout << "\n== InputValidator (interactive, scripted input) ==\n";
    using namespace InputValidator;
    {   // letters, empty line, out-of-range, then a valid number: must not loop forever or crash
        std::istringstream in("abc\n\n99\n-5\n3\n");
        std::ostringstream out;
        check(readInt("n: ", 1, 5, in, out) == 3, "readInt skips letters/empty/out-of-range until valid");
        check(out.str().find("Invalid input") != std::string::npos, "readInt explains the error");
    }
    {   // closed input stream must raise an exception instead of an infinite loop
        std::istringstream in("");
        std::ostringstream out;
        check(throwsError<InputClosedError>([&] { readInt("n: ", 1, 5, in, out); }), "EOF raises InputClosedError");
    }
    {
        std::istringstream in("maybe\nY\n");
        std::ostringstream out;
        check(confirm("sure?", in, out), "confirm retries then accepts 'Y'");
    }
    {
        std::istringstream in("n\n");
        std::ostringstream out;
        check(!confirm("sure?", in, out), "confirm accepts 'n'");
    }
    {
        std::istringstream in("   \n" + std::string(150, 'x') + "\nGood Name\n");
        std::ostringstream out;
        check(readRequiredText("name: ", in, out) == "Good Name", "readRequiredText rejects blank and over-long input");
    }
    {
        std::istringstream in("\r\n7\r\n");   // Windows line endings
        std::ostringstream out;
        check(readOptionalInt("n: ", 9, 1, 10, in, out) == 9, "readOptionalInt: empty keeps current value");
        check(readOptionalInt("n: ", 9, 1, 10, in, out) == 7, "readOptionalInt handles CRLF input");
    }
}

void testCsv() {
    g_currentGroup = "FileManager CSV";
    std::cout << "\n== FileManager: CSV escaping and parsing ==\n";
    std::vector<std::string> f;
    check(FileManager::escapeField("plain") == "plain", "plain field not quoted");
    check(FileManager::escapeField("a,b") == "\"a,b\"", "comma field quoted");
    check(FileManager::escapeField("say \"hi\"") == "\"say \"\"hi\"\"\"", "quotes doubled");
    check(FileManager::escapeField("line1\nline2") == "line1 line2", "newline replaced by space");
    check(FileManager::splitCsvLine("1,\"a,b\",\"c\"\"d\",e", f) && f.size() == 4 && f[1] == "a,b" && f[2] == "c\"d" && f[3] == "e",
          "split handles quoted commas and doubled quotes");
    check(FileManager::splitCsvLine(",,", f) && f.size() == 3, "split keeps empty fields");
    check(!FileManager::splitCsvLine("a,\"unterminated", f), "unterminated quote rejected");
    check(!FileManager::splitCsvLine("a,b\"c", f), "quote in the middle of a field rejected");
    check(!FileManager::splitCsvLine("\"ab\"cd,e", f), "text after closing quote rejected");
    const std::string tricky = "He said, \"Hello\", O'Brien & <Sons>";
    std::vector<std::string> round;
    check(FileManager::splitCsvLine(FileManager::escapeField(tricky) + ",x", round) && round[0] == tricky,
          "escape + split round trip with special characters");
}

void testBookInventory() {
    g_currentGroup = "Book inventory";
    std::cout << "\n== Book inventory ==\n";
    TempDir dir;
    Library lib(dir.str() + "/db");
    check(lib.load().empty(), "load on a fresh directory has no warnings");
    check(lib.books().empty(), "empty database has no books");

    const int id1 = lib.addBook(sampleBook());
    check(id1 == 1, "first book gets ID 1");
    check(lib.findBook(id1)->isbn() == "9780132350884", "ISBN stored without hyphens");
    check(lib.findBook(id1)->availableCopies() == 3 && lib.findBook(id1)->totalCopies() == 3, "new book: available == total");
    const int id2 = lib.addBook(sampleBook("9780262046305", "Introduction to Algorithms", 1));
    check(id2 == 2, "second book gets a unique ID");
    check(lib.books().size() == 2, "two books stored");

    check(throwsError<LibraryError>([&] { lib.addBook(sampleBook("978-0-13-235088-4", "Other title")); }), "duplicate ISBN rejected");
    check(throwsError<LibraryError>([&] { lib.addBook(sampleBook("1234", "X")); }), "invalid ISBN rejected");
    check(throwsError<LibraryError>([&] { lib.addBook(sampleBook("9780141439518", "Pride", 0)); }), "zero copies rejected");
    check(throwsError<LibraryError>([&] { lib.addBook(sampleBook("9780141439518", "Pride", -4)); }), "negative copies rejected");
    check(throwsError<LibraryError>([&] { lib.addBook(sampleBook("9780141439518", "", 1)); }), "empty title rejected");
    check(throwsError<LibraryError>([&] { lib.addBook(sampleBook("9780141439518", std::string(101, 'T'), 1)); }), "over-long title rejected");
    BookData badYear = sampleBook("9780141439518", "Pride", 1); badYear.year = 3000;
    check(throwsError<LibraryError>([&] { lib.addBook(badYear); }), "invalid year rejected");
    check(lib.books().size() == 2, "rejected books were not stored");

    BookData special = sampleBook("9780141439518", "Tom & Jerry's \"Big\" Book, Vol. 1", 2);
    special.author = "Ünal Çelik";
    const int id3 = lib.addBook(special);
    check(lib.findBook(id3)->title() == "Tom & Jerry's \"Big\" Book, Vol. 1", "special characters accepted");

    // update
    BookData upd = sampleBook("9780132350884", "Clean Code (2nd printing)", 5);
    lib.updateBook(id1, upd);
    check(lib.findBook(id1)->title() == "Clean Code (2nd printing)" && lib.findBook(id1)->totalCopies() == 5 &&
          lib.findBook(id1)->availableCopies() == 5, "update changes title and copies");
    check(throwsError<LibraryError>([&] { lib.updateBook(99, upd); }), "update of unknown ID rejected");
    BookData clash = sampleBook("9780262046305", "Clash", 1);
    check(throwsError<LibraryError>([&] { lib.updateBook(id1, clash); }), "update to another book's ISBN rejected");

    // search
    check(lib.searchBooksByTitle("clean").size() == 1, "search by title is case-insensitive");
    check(lib.searchBooksByTitle("zzz").empty(), "search with no match is empty");
    check(lib.searchBooksByAuthor("martin").size() == 2, "search by author finds both Martin books");
    check(lib.searchBooksByIsbn("978-0-26-204630-5").size() == 1, "search by ISBN with hyphens");
    check(lib.searchBooksByIsbn("").empty(), "search by empty ISBN returns nothing");
    check(lib.searchBooksByCategory("SOFT").size() == 3, "search by category");
    check(lib.findBook(2) != nullptr && lib.findBook(404) == nullptr, "search by ID");

    // sorting
    const std::vector<Book> byTitle = lib.booksSortedByTitle();
    check(byTitle.size() == 3 && byTitle[0].title() == "Clean Code (2nd printing)" && byTitle[1].title() == "Introduction to Algorithms",
          "sorted by title A-Z");
    BookData old = sampleBook("9780201633610", "Zebra Book", 1); old.year = 1994;
    lib.addBook(old);
    const std::vector<Book> byYear = lib.booksSortedByYear();
    check(byYear.front().year() == 1994 && byYear.back().year() >= byYear[byYear.size() - 2].year(), "sorted by year ascending");

    // delete
    lib.deleteBook(id2);
    check(lib.findBook(id2) == nullptr, "eligible book deleted");
    check(throwsError<LibraryError>([&] { lib.deleteBook(id2); }), "deleting twice rejected");
    const int idNew = lib.addBook(sampleBook("9780262046305", "Introduction to Algorithms", 1));
    check(idNew > id3, "deleted IDs are never reused");
}

void testMembers() {
    g_currentGroup = "Members";
    std::cout << "\n== Member management ==\n";
    TempDir dir;
    Library lib(dir.str());
    lib.load();
    const int m1 = lib.addMember(sampleMember(), "2024-01-10");
    check(m1 == 1 && lib.findMember(m1)->registrationDate() == "2024-01-10", "member registered with ID and date");
    check(lib.addMember(sampleMember("Bilal", "bilal@example.com")) == 2, "second member unique ID");
    check(throwsError<LibraryError>([&] { lib.addMember(sampleMember("Dup", "AYESHA@example.com")); }), "duplicate email (case-insensitive) rejected");
    check(throwsError<LibraryError>([&] { lib.addMember(sampleMember("", "x@example.com")); }), "empty name rejected");
    check(throwsError<LibraryError>([&] { lib.addMember(sampleMember("X", "not-an-email")); }), "invalid email rejected");
    MemberData badPhone = sampleMember("Y", "y@example.com"); badPhone.phone = "abc";
    check(throwsError<LibraryError>([&] { lib.addMember(badPhone); }), "invalid phone rejected");
    check(throwsError<LibraryError>([&] { lib.addMember(sampleMember("Z", "z@example.com"), "2024-13-45"); }), "invalid registration date rejected");
    check(lib.members().size() == 2, "rejected members were not stored");
    check(lib.addMember(sampleMember("Zoë \"Z\" O'Neil, Jr.", "zoe@example.com")) == 3, "special characters in name accepted");

    MemberData upd = sampleMember("Ayesha K. Khan", "ayesha@example.com");
    upd.phone = "0300-0000000";
    lib.updateMember(m1, upd);
    check(lib.findMember(m1)->name() == "Ayesha K. Khan" && lib.findMember(m1)->phone() == "0300-0000000", "member updated");
    check(throwsError<LibraryError>([&] { lib.updateMember(m1, sampleMember("A", "bilal@example.com")); }), "update to another member's email rejected");
    check(throwsError<LibraryError>([&] { lib.updateMember(77, upd); }), "update unknown member rejected");

    check(lib.searchMembersByName("khan").size() == 1, "search member by name");
    check(lib.searchMembersByName("nobody").empty(), "search member no match");
    check(lib.findMember(2) != nullptr && lib.findMember(50) == nullptr, "find member by ID");
    lib.deleteMember(2);
    check(lib.findMember(2) == nullptr, "member without loans deleted");
    check(throwsError<LibraryError>([&] { lib.deleteMember(2); }), "deleting unknown member rejected");
}

void testIssueAndReturn() {
    g_currentGroup = "Issue/Return";
    std::cout << "\n== Issue and return ==\n";
    TempDir dir;
    Library lib(dir.str());
    lib.load();
    const int book = lib.addBook(sampleBook("9780132350884", "Clean Code", 2));
    const int single = lib.addBook(sampleBook("9780262046305", "Algorithms", 1));
    const int m1 = lib.addMember(sampleMember("A", "a@example.com"));
    const int m2 = lib.addMember(sampleMember("B", "b@example.com"));
    const int m3 = lib.addMember(sampleMember("C", "c@example.com"));

    const Transaction t1 = lib.issueBook(book, m1, "2024-03-01");
    check(t1.id() == 1 && t1.isActive(), "issue creates active transaction with ID 1");
    check(t1.issueDate() == "2024-03-01" && t1.dueDate() == "2024-03-15", "due date = issue date + 14 days");
    check(lib.findBook(book)->availableCopies() == 1, "available copies decreased");
    check(throwsError<LibraryError>([&] { lib.issueBook(book, m1, "2024-03-02"); }), "duplicate active issue to same member rejected");
    check(lib.findBook(book)->availableCopies() == 1, "failed duplicate issue did not change stock");
    check(throwsError<LibraryError>([&] { lib.issueBook(book, 999); }), "invalid member ID rejected");
    check(throwsError<LibraryError>([&] { lib.issueBook(999, m1); }), "invalid book ID rejected");
    check(throwsError<LibraryError>([&] { lib.issueBook(book, m2, "2024-02-30"); }), "invalid issue date rejected");

    lib.issueBook(single, m1, "2024-03-01");
    check(lib.findBook(single)->availableCopies() == 0, "last copy issued -> 0 available");
    check(throwsError<LibraryError>([&] { lib.issueBook(single, m2, "2024-03-01"); }), "unavailable book cannot be issued");
    check(throwsError<LibraryError>([&] { lib.deleteMember(m1); }), "member with active loans cannot be deleted");
    check(throwsError<LibraryError>([&] { lib.deleteBook(single); }), "book with active loans cannot be deleted");
    {
        bool allowed = true;
        try { lib.updateBook(single, sampleBook("9780262046305", "Algorithms", 1)); } catch (...) { allowed = false; }
        check(allowed && lib.findBook(single)->availableCopies() == 0, "updating an issued book keeps issued count");
    }
    BookData shrink = sampleBook("9780132350884", "Clean Code", 0);
    check(throwsError<LibraryError>([&] { lib.updateBook(book, shrink); }), "total copies below issued count rejected");

    // return on time
    const Transaction r1 = lib.returnBook(t1.id(), "2024-03-15");
    check(!r1.isActive() && r1.returnDate() == "2024-03-15", "return records date");
    check(r1.fineCents() == 0 && lib.overdueDays(r1) == 0, "returned on due date -> no fine");
    check(lib.findBook(book)->availableCopies() == 2, "available copies restored");
    check(throwsError<LibraryError>([&] { lib.returnBook(t1.id(), "2024-03-16"); }), "double return rejected");
    check(lib.findBook(book)->availableCopies() == 2, "double return did not change stock");
    check(throwsError<LibraryError>([&] { lib.returnBook(999); }), "return of unknown transaction rejected");
    check(lib.findTransaction(t1.id())->returnDate() == "2024-03-15", "history keeps original return date");

    // late return with fine (0.50/day default)
    const Transaction t3 = lib.issueBook(book, m3, "2024-04-01");
    check(throwsError<LibraryError>([&] { lib.returnBook(t3.id(), "2024-03-31"); }), "return before issue date rejected");
    check(throwsError<LibraryError>([&] { lib.returnBook(t3.id(), "not-a-date"); }), "invalid return date rejected");
    const Transaction r3 = lib.returnBook(t3.id(), "2024-04-25");  // due 04-15 -> 10 days late
    check(lib.overdueDays(r3) == 10, "10 overdue days calculated");
    check(r3.fineCents() == 500, "fine = 10 x 0.50 = 5.00");

    lib.setFinePerDayCents(125);
    const Transaction t4 = lib.issueBook(book, m3, "2024-05-01");
    const Transaction r4 = lib.returnBook(t4.id(), "2024-05-18");  // 3 days late
    check(r4.fineCents() == 375, "configurable rate: 3 x 1.25 = 3.75");
    lib.setLoanPeriodDays(7);
    const Transaction t5 = lib.issueBook(book, m1, "2024-06-01");
    check(t5.dueDate() == "2024-06-08", "configurable loan period (7 days)");
    check(throwsError<LibraryError>([&] { lib.setLoanPeriodDays(0); }), "loan period 0 rejected");
    check(throwsError<LibraryError>([&] { lib.setFinePerDayCents(-1); }), "negative fine rate rejected");

    // member can be deleted after returning everything
    lib.returnBook(2, "2024-03-10");  // 'single' loan by m1
    lib.returnBook(t5.id(), "2024-06-02");
    check(lib.activeLoansForMember(m1) == 0, "member has no active loans after returns");
    lib.deleteMember(m1);
    check(lib.findMember(m1) == nullptr, "member deleted after returning everything");
    check(lib.transactions().size() == 5 && lib.findTransaction(t1.id()) != nullptr, "history survives member deletion");
}

void testReports() {
    g_currentGroup = "Reports";
    std::cout << "\n== Reports and statistics ==\n";
    TempDir dir;
    Library lib(dir.str());
    lib.load();
    ReportManager reports(lib);
    Statistics empty = reports.compute("2024-06-01");
    check(empty.totalBookTitles == 0 && empty.totalCopies == 0 && empty.totalMembers == 0 && empty.activeTransactions == 0,
          "empty database gives zero statistics");
    check(reports.mostBorrowed().empty(), "no history -> no most-borrowed list");

    const int b1 = lib.addBook(sampleBook("9780132350884", "Clean Code", 3));
    const int b2 = lib.addBook(sampleBook("9780262046305", "Algorithms", 2));
    const int m1 = lib.addMember(sampleMember("A", "a@example.com"));
    const int m2 = lib.addMember(sampleMember("B", "b@example.com"));
    lib.issueBook(b1, m1, "2024-01-01");                          // tx 1: will stay out (overdue)
    const Transaction t2 = lib.issueBook(b1, m2, "2024-01-01");   // tx 2: returned late
    const Transaction t3 = lib.issueBook(b2, m1, "2024-01-01");   // tx 3: returned on time
    lib.returnBook(t2.id(), "2024-01-20");                        // 5 days late = 2.50
    lib.returnBook(t3.id(), "2024-01-10");

    Statistics s = reports.compute("2024-02-01");                 // tx 1 due 01-15 -> 17 days late = 8.50
    check(s.totalBookTitles == 2, "report: total titles");
    check(s.totalCopies == 5 && s.availableCopies == 4 && s.issuedCopies == 1, "report: copies total/available/issued");
    check(s.totalMembers == 2, "report: members");
    check(s.activeTransactions == 1 && s.returnedTransactions == 2, "report: active and returned");
    check(s.overdueTransactions == 1, "report: overdue count");
    check(s.outstandingFinesCents == 850, "report: outstanding fines (17 days x 0.50)");
    check(s.collectedFinesCents == 250, "report: fines recorded on returns");
    check(reports.compute("2024-01-10").overdueTransactions == 0, "report: nothing overdue before due date");

    const std::vector<BorrowCount> top = reports.mostBorrowed();
    check(top.size() == 2 && top[0].bookId == b1 && top[0].timesBorrowed == 2 && top[1].timesBorrowed == 1, "report: most borrowed ordering");
    std::ostringstream out;
    reports.printSummary(out, "2024-02-01");
    check(out.str().find("8.50") != std::string::npos && out.str().find("2.50") != std::string::npos, "printed summary shows computed fines");
    lib.returnBook(1, "2024-02-01");
    lib.deleteBook(b2);
    check(reports.mostBorrowed(5).size() == 2, "most borrowed still lists history of a deleted book");
    check(reports.mostBorrowed(1).size() == 1, "most borrowed respects the limit");
}

void testPersistence() {
    g_currentGroup = "Persistence";
    std::cout << "\n== Persistence and data integrity ==\n";
    TempDir dir;
    int book = 0, member = 0, tx = 0;
    {
        Library lib(dir.str() + "/data");
        lib.load();
        check(fs::exists(dir.file("data/books.csv")) && fs::exists(dir.file("data/members.csv")) &&
              fs::exists(dir.file("data/transactions.csv")) && fs::exists(dir.file("data/settings.ini")),
              "all data files are created automatically (including the directory)");
        BookData tricky = sampleBook("9780132350884", "Comma, \"Quote\" & Co", 2);
        tricky.author = "Ünal, Çelik";
        book = lib.addBook(tricky);
        member = lib.addMember(sampleMember("Ayesha \"Aisha\" Khan, PhD", "ayesha@example.com"), "2024-01-10");
        tx = lib.issueBook(book, member, "2024-03-01").id();
        lib.setLoanPeriodDays(21);
        lib.setFinePerDayCents(75);
    }
    {   // "restart": a brand-new Library object reads the files
        Library lib(dir.str() + "/data");
        check(lib.load().empty(), "reload gives no warnings");
        check(lib.books().size() == 1 && lib.findBook(book)->title() == "Comma, \"Quote\" & Co", "book persisted with special characters");
        check(lib.findBook(book)->author() == "Ünal, Çelik", "UTF-8 text persisted");
        check(lib.findBook(book)->availableCopies() == 1 && lib.findBook(book)->totalCopies() == 2, "copy counts persisted");
        check(lib.findMember(member)->name() == "Ayesha \"Aisha\" Khan, PhD", "member persisted with special characters");
        check(lib.findMember(member)->registrationDate() == "2024-01-10", "registration date persisted");
        check(lib.findTransaction(tx) != nullptr && lib.findTransaction(tx)->isActive(), "active transaction persisted");
        check(lib.findTransaction(tx)->dueDate() == "2024-03-15", "due date persisted unchanged (issue + 14 days)");
        check(lib.settings().loanPeriodDays == 21 && lib.settings().finePerDayCents == 75, "settings persisted");
        lib.returnBook(tx, "2024-03-30");
    }
    {
        Library lib(dir.str() + "/data");
        lib.load();
        check(!lib.findTransaction(tx)->isActive() && lib.findBook(book)->availableCopies() == 2, "return persisted; book no longer marked as issued");
        check(lib.findTransaction(tx)->fineCents() == 15 * 75 && lib.findTransaction(tx)->returnDate() == "2024-03-30", "fine (15 days x 0.75) and return date persisted");
        const int next = lib.addBook(sampleBook("9780262046305", "Another", 1));
        check(next == book + 1, "ID counter continues after restart");
        lib.deleteBook(next);
    }
    {
        Library lib(dir.str() + "/data");
        lib.load();
        check(lib.addBook(sampleBook("9780262046305", "Another", 1)) == book + 2, "IDs not reused after deleting the newest record");
    }
}

void testRobustLoading() {
    g_currentGroup = "Robust loading";
    std::cout << "\n== Missing, empty and corrupted files ==\n";
    {   // empty (zero byte) files
        TempDir dir;
        writeText(dir.file("books.csv"), "");
        writeText(dir.file("members.csv"), "");
        writeText(dir.file("transactions.csv"), "");
        writeText(dir.file("settings.ini"), "");
        Library lib(dir.str());
        check(lib.load().empty() && lib.books().empty(), "empty files load without errors");
        check(lib.addBook(sampleBook()) == 1, "library usable after loading empty files");
    }
    {   // only some files missing
        TempDir dir;
        {
            Library lib(dir.str());
            lib.load();
            lib.addBook(sampleBook());
        }
        fs::remove(dir.file("members.csv"));
        fs::remove(dir.file("settings.ini"));
        Library lib(dir.str());
        lib.load();
        check(lib.books().size() == 1, "books survive when other files are missing");
        check(fs::exists(dir.file("members.csv")) && fs::exists(dir.file("settings.ini")), "missing files are recreated");
    }
    {   // corrupted lines
        TempDir dir;
        const std::string good = "1,9780132350884,Clean Code,Robert C. Martin,Prentice Hall,Software,2008,3,3\n";
        const std::string content = std::string(FileManager::kBooksHeader) + "\n" + good +
            "this is not a record\n"                                                      // wrong field count
            "x,9780262046305,Bad Id,A,B,C,2000,1,1\n"                                       // non-numeric ID
            "3,9780262046305,Neg,A,B,C,2000,-1,-1\n"                                        // negative copies
            "4,9780262046305,Over,A,B,C,2000,2,5\n"                                         // available > total
            "5,9780262046305,\"Unterminated,A,B,C,2000,1,1\n"                               // broken quote
            "6,12345,Bad Isbn,A,B,C,2000,1,1\n"                                             // invalid ISBN
            "7,9780141439518,Bad Year,A,B,C,12,1,1\n"                                       // invalid year
            "8,9780141439518,Good Two,A,B,C,2001,1,1\n";
        writeText(dir.file("books.csv"), content);
        Library lib(dir.str());
        const std::vector<std::string> warnings = lib.load();
        check(lib.books().size() == 2, "only the 2 valid book records are loaded");
        check(!warnings.empty(), "corrupted lines produce warnings");
        check(fs::exists(dir.file("books.csv.corrupt.bak")), "original corrupted file is backed up");
        check(readText(dir.file("books.csv.corrupt.bak")) == content, "backup is byte-identical to the original");
        check(lib.addBook(sampleBook("9780201633610", "New", 1)) == 9, "new IDs continue after the highest valid ID");
    }
    {   // inconsistent data: duplicates and wrong available count
        TempDir dir;
        writeText(dir.file("books.csv"), std::string(FileManager::kBooksHeader) + "\n"
            "1,9780132350884,A,A,P,C,2000,3,3\n"
            "1,9780262046305,Dup Id,A,P,C,2000,1,1\n"
            "2,9780132350884,Dup Isbn,A,P,C,2000,1,1\n"
            "3,9780141439518,C,A,P,C,2000,2,2\n");
        writeText(dir.file("members.csv"), std::string(FileManager::kMembersHeader) + "\n"
            "1,A,0300 1234567,a@example.com,2024-01-01\n"
            "2,B,0300 1234567,A@EXAMPLE.COM,2024-01-01\n");
        writeText(dir.file("transactions.csv"), std::string(FileManager::kTransactionsHeader) + "\n"
            "1,1,1,2024-01-01,2024-01-15,,0\n"
            "1,3,1,2024-01-01,2024-01-15,,0\n"          // duplicate transaction ID
            "2,77,1,2024-01-01,2024-01-15,,0\n"         // active loan of a missing book
            "3,3,1,2024-01-20,2024-01-10,,0\n"          // due before issue
            "4,3,1,2024-01-01,2024-01-15,2024-01-05,0\n");
        Library lib(dir.str());
        const std::vector<std::string> warnings = lib.load();
        check(lib.books().size() == 2, "duplicate book ID/ISBN dropped");
        check(lib.members().size() == 1, "duplicate member email dropped");
        check(lib.transactions().size() == 2, "duplicate/invalid transactions dropped, returned history kept");
        check(lib.findBook(1)->availableCopies() == 2, "available copies repaired from active loans (3 total - 1 active)");
        check(!warnings.empty() && fs::exists(dir.file("books.csv.corrupt.bak")), "warnings and backups created");
        check(lib.addBook(sampleBook("9780201633610", "Next", 1)) > 3, "new book IDs stay above all IDs seen");
    }
    {   // bad settings file
        TempDir dir;
        writeText(dir.file("settings.ini"), "loan_period_days=abc\nfine_per_day_cents=-5\nloan_period_days=9999\nnonsense\nnext_book_id=50\n");
        Library lib(dir.str());
        const std::vector<std::string> warnings = lib.load();
        check(lib.settings().loanPeriodDays == 14 && lib.settings().finePerDayCents == 50, "invalid settings fall back to defaults");
        check(warnings.size() >= 3, "invalid settings produce warnings");
        check(lib.addBook(sampleBook()) == 50, "valid counter in settings file is honoured");
    }
    {   // BOM + CRLF (files edited in Windows Notepad / Excel)
        TempDir dir;
        writeText(dir.file("members.csv"), "\xEF\xBB\xBF" + std::string(FileManager::kMembersHeader) + "\r\n"
            "1,Ayesha,0300 1234567,a@example.com,2024-01-01\r\n");
        Library lib(dir.str());
        check(lib.load().empty() && lib.members().size() == 1, "UTF-8 BOM and CRLF line endings are handled");
    }
    {   // very long text in a data file
        TempDir dir;
        writeText(dir.file("books.csv"), std::string(FileManager::kBooksHeader) + "\n1,9780132350884," +
                  std::string(5000, 'T') + ",A,P,C,2000,1,1\n");
        Library lib(dir.str());
        check(!lib.load().empty() && lib.books().empty(), "very long text field is rejected on load");
    }
    {   // data directory that cannot be created
        TempDir dir;
        writeText(dir.file("blocker"), "i am a file");
        Library lib(dir.file("blocker") + "/sub");
        check(throwsError<LibraryError>([&] { lib.load(); }), "unusable data directory raises a clear error");
    }
}

void testSaveFailureRollback() {
    g_currentGroup = "Rollback";
    std::cout << "\n== Rollback when saving fails ==\n";
    TempDir dir;
    Library lib(dir.str());
    lib.load();
    lib.addBook(sampleBook());
    // Make saving impossible: replace books.csv by a directory.
    fs::remove(dir.file("books.csv"));
    fs::create_directory(dir.file("books.csv"));
    fs::create_directory(dir.file("books.csv") + "/blocker");  // non-empty directory cannot be replaced
    check(throwsError<LibraryError>([&] { lib.addBook(sampleBook("9780262046305", "Second", 1)); }), "failed save reports an error");
    check(lib.books().size() == 1 && lib.findBook(2) == nullptr, "in-memory state rolled back after failed save");
    fs::remove_all(dir.file("books.csv"));
    check(lib.addBook(sampleBook("9780262046305", "Second", 1)) == 2, "library works again once saving is possible (ID not consumed)");
}

void testSampleData() {
    g_currentGroup = "Sample data";
    std::cout << "\n== Sample data import ==\n";
    TempDir dir;
    Library lib(dir.str());
    lib.load();
    std::size_t books = 0, members = 0;
    const std::string root = TEST_PROJECT_ROOT;
    lib.importSampleData(root + "/data/sample_books.csv", root + "/data/sample_members.csv", books, members);
    check(books == 12 && members == 6, "sample files import 12 books and 6 members");
    check(lib.findMember(6) != nullptr && lib.findMember(6)->name() == "Hamza \"Hammy\" Ali", "quoted sample name parsed");
    check(throwsError<LibraryError>([&] { lib.importSampleData(root + "/data/sample_books.csv", root + "/data/sample_members.csv", books, members); }),
          "import refused when library is not empty");
    Library again(dir.str());
    check(again.load().empty() && again.books().size() == 12, "imported data persisted");
    TempDir other;
    Library lib2(other.str());
    lib2.load();
    check(throwsError<LibraryError>([&] { lib2.importSampleData("nope.csv", "nope2.csv", books, members); }), "missing sample files give a clear error");
}

// Drives the real console interface with scripted keyboard input.
void testConsoleUI() {
    g_currentGroup = "Console UI";
    std::cout << "\n== Console interface (scripted input) ==\n";
    {
        TempDir dir;
        Library lib(dir.str());
        lib.load();
        std::istringstream in(
            "abc\n"          // letters instead of a menu number
            "\n"             // empty line
            "99\n"           // out-of-range
            "-1\n"
            "9\n\n"          // help screen, Enter to continue
            "0\n");          // exit
        std::ostringstream out;
        ConsoleUI ui(lib, in, out);
        ui.run();
        check(out.str().find("Invalid input") != std::string::npos, "invalid menu input is rejected with a message");
        check(out.str().find("HELP AND ABOUT") != std::string::npos, "help screen is shown");
        check(out.str().find("Goodbye") != std::string::npos, "clean exit message");
    }
    {
        TempDir dir;
        Library lib(dir.str());
        lib.load();
        std::istringstream in(
            "3\n1\n"                                        // member menu -> register
            "Test User\nbad-phone\n0300 1112233\nnotanemail\ntest@example.com\n\n"
            "0\n"                                           // back
            "2\n1\n"                                        // book menu -> add
            "12345\n978-0-13-235088-4\nClean Code\nR. Martin\nPrentice\nSoftware\nabc\n2008\n0\n2\n\n"
            "0\n"
            "4\n1\n1\n\n"                                   // issue book 1 to member 1
            "4\n1\n1\n\n"                                   // duplicate issue -> error message
            "3\n3\n1\ny\n\n0\n"                             // try deleting member with active loan
            "5\n1\n1\n\n0\n"                                // return transaction 1
            "0\n");
        std::ostringstream out;
        ConsoleUI ui(lib, in, out);
        ui.run();
        const std::string text = out.str();
        check(lib.members().size() == 1 && lib.books().size() == 1, "UI: member and book created through menus");
        check(text.find("Invalid input") != std::string::npos && text.find("[!]") != std::string::npos, "UI: invalid field values re-prompted");
        check(text.find("already has this book issued") != std::string::npos, "UI: duplicate issue error shown");
        check(text.find("Cannot delete") != std::string::npos, "UI: deleting a member with loans refused");
        check(lib.transactions().size() == 1 && !lib.transactions()[0].isActive(), "UI: book returned");
        check(lib.findBook(1)->availableCopies() == lib.findBook(1)->totalCopies(), "UI: stock restored after return");
    }
    {   // input ends abruptly (Ctrl+Z / closed pipe): must throw, not hang
        TempDir dir;
        Library lib(dir.str());
        lib.load();
        std::istringstream in("2\n");
        std::ostringstream out;
        ConsoleUI ui(lib, in, out);
        check(throwsError<InputClosedError>([&] { ui.run(); }), "UI: end of input stops the program instead of looping");
    }
}

}  // namespace

int main() {
    std::cout << "Library Management System - automated tests\n";
    std::cout << "============================================\n";
    const std::vector<void (*)()> groups = {
        testDateUtils, testValidators, testInteractiveInput, testCsv, testBookInventory, testMembers,
        testIssueAndReturn, testReports, testPersistence, testRobustLoading, testSaveFailureRollback,
        testSampleData, testConsoleUI};
    for (auto group : groups) {
        try {
            group();
        } catch (const std::exception& e) {
            ++g_failed;
            std::cout << "  [FAIL] " << g_currentGroup << ": unexpected exception: " << e.what() << "\n";
        } catch (...) {
            ++g_failed;
            std::cout << "  [FAIL] " << g_currentGroup << ": unexpected unknown exception\n";
        }
    }
    std::cout << "\n============================================\n"
              << "SUMMARY: " << (g_passed + g_failed) << " checks, " << g_passed << " passed, " << g_failed << " failed\n"
              << (g_failed == 0 ? "RESULT: ALL TESTS PASSED\n" : "RESULT: SOME TESTS FAILED\n");
    return g_failed == 0 ? 0 : 1;
}
