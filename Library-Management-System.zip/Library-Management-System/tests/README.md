# Automated tests

`test_main.cpp` is a self-contained test program (no external framework). It prints `[PASS]`/`[FAIL]` per check, a summary, and returns exit code 0 only if everything passed.

Run from the project root:

```
build.bat test                     (Windows)
```
or
```
cmake -S . -B build && cmake --build build && ctest --test-dir build --output-on-failure
```
or compile it manually together with the sources in `src/` except `main.cpp` (see docs/TESTING.md).

All tests create and delete their own temporary folders (`lms_test_*` in the system temp directory); real data in `data/db/` and the sample files are never modified. The sample-data test reads `data/sample_*.csv`, so run the tests from the project root.
