# Architecture

## Layers and responsibilities

| Module | Responsibility | Depends on |
|---|---|---|
| `Book`, `Member`, `Transaction` | Entity classes. Keep their own invariants (e.g. `0 <= available <= total`) and throw `std::invalid_argument` when given bad data. | `InputValidator`, `DateUtils` |
| `Library` | Business logic: all rules (availability, duplicates, deletion rules, fines), ID generation, indexes, load/save orchestration, rollback. Throws `LibraryError` with user-readable messages. | entities, `FileManager`, `DateUtils` |
| `FileManager` | Only place that touches files: CSV escaping/parsing, atomic writes, backups, loaders that never crash on bad data. | entities, `InputValidator` |
| `ReportManager` | Read-only statistics over a `const Library&`. | `Library` |
| `InputValidator` | Pure validation functions and safe interactive readers (`readInt`, `confirm`, ...). Streams are parameters, so they can be scripted in tests. | none |
| `DateUtils` | Date parsing/validation/arithmetic on `YYYY-MM-DD` strings. | none |
| `ConsoleUI` | Menus and screens. Contains no business rules; every action calls `Library`. | `Library`, `ReportManager`, `InputValidator` |
| `main.cpp` | Parses the optional data-folder argument, loads data, runs the UI, handles fatal errors. | all |

```
main -> ConsoleUI -> Library -> FileManager -> disk
                  \-> ReportManager -> Library (const)
```

## Data structures and why

- `std::vector<Book/Member/Transaction>` - primary storage. Records are few enough to scan linearly, iteration/printing is trivial, and `std::sort` works directly on copies for sorted views.
- `std::unordered_map<int, size_t>` - ID -> index in the vector for O(1) lookup. Rebuilt after every change (O(n), negligible at this scale), which avoids stale indexes after deletions.
- `std::unordered_map<int,int>` - temporary counters (loans per book) in reports and load-time repair.
- `std::set` - duplicate detection while loading.
- `std::sort` with case-insensitive comparison and a tie-breaker on ID for deterministic output.

## Key design decisions

1. **Available copies are derived data.** The loan records are the source of truth: available = total - active loans. `Library` keeps them in sync, and `load()` repairs any mismatch found in the files.
2. **Commit with rollback.** Every mutation runs through `Library::commit`: copy the state, apply the change, rebuild indexes, save; on any exception restore the copy. Memory and disk therefore never disagree. (Copying is acceptable for the intended data size.)
3. **Exceptions for rule violations.** `LibraryError` carries a message meant for the user; the UI prints it and returns to the menu. Entities throw `std::invalid_argument`, which `Library` converts to `LibraryError`.
4. **IDs persist in `settings.ini`** (next ID counters) and are also checked against the highest ID seen at load time, so IDs of deleted records are never reused and history never points to the wrong book.
5. **Money in integer hundredths** (`fine_per_day_cents`) to avoid floating-point rounding errors.
6. **Dates as ISO text** with a self-contained civil-date algorithm: no time-zone or locale problems, trivially sortable, readable in the CSV files.
7. **Atomic file replacement** (write `.tmp`, rename) so a crash cannot leave a half-written file; corrupted input is backed up before it can be overwritten.
8. **Testable I/O.** `ConsoleUI` and `InputValidator` take `std::istream&`/`std::ostream&`, so the real menus are tested with scripted keyboard input.
9. **History is preserved.** Deleting a book or member keeps old transactions; reports show "[deleted book]" where needed.

## File formats

`books.csv`: `id,isbn,title,author,publisher,category,year,total_copies,available_copies`
`members.csv`: `id,name,phone,email,registered_date`
`transactions.csv`: `id,book_id,member_id,issue_date,due_date,return_date,fine_cents` (empty return date = active)
`settings.ini`: `key=value` lines (`loan_period_days`, `fine_per_day_cents`, `next_book_id`, `next_member_id`, `next_transaction_id`)

Fields containing a comma or quote are wrapped in double quotes with inner quotes doubled (standard CSV). Line breaks inside fields are replaced by spaces.
