# Testing and Verification Report

Date of verification: 2026-11-09. Everything below was actually executed; nothing is estimated.
Items that could not be executed are marked **NOT TESTED**.

## 1. Environments used

| Environment | Compiler / tool | Version |
|---|---|---|
| Linux x86-64 (Ubuntu 24.04) | g++ | 13.3.0 |
| Linux, sanitizers | g++ with `-fsanitize=address,undefined` | 13.3.0 |
| Linux, CMake build | CMake | 4.4.4 |
| Windows executable (cross-compiled on Linux) | x86_64-w64-mingw32-g++ (MinGW-w64, posix threads) | GCC 13 |
| Running the Windows executable | Wine (Windows API emulation, not real Windows) | 9.0 |

## 2. Commands

Build the application (Linux, strict warnings):
```
g++ -std=c++17 -O2 -Wall -Wextra -Wpedantic -Wshadow -Wconversion -Werror -Iinclude src/*.cpp -o lms
```
Build and run the automated tests (Linux):
```
g++ -std=c++17 -O2 -Wall -Wextra -Wpedantic -Iinclude tests/test_main.cpp src/Book.cpp src/Member.cpp src/Transaction.cpp src/Library.cpp src/FileManager.cpp src/ReportManager.cpp src/InputValidator.cpp src/DateUtils.cpp src/ConsoleUI.cpp -o lms_tests
./lms_tests            # run from the project root
```
With CMake: `cmake -S . -B build && cmake --build build && ctest --test-dir build`
On Windows (to be run by the user): `build.bat test`

## 3. Results

| Test run | Checks | Passed | Failed |
|---|---|---|---|
| Linux, g++ 13.3, `-O2`, warnings as errors | 224 | 224 | 0 |
| Linux, g++ 13.3, `-O1 -g` + AddressSanitizer + UBSan (`-fno-sanitize-recover`) | 224 | 224 | 0 |
| CMake build + CTest (1 CTest test wrapping the whole suite) | 224 | 224 | 0 |
| Windows .exe (MinGW-w64 GCC 13) under Wine 9.0 | 224 | 224 | 0 |

Compilation: all 10 source files plus the test file compile with **zero warnings** under `-Wall -Wextra -Wpedantic -Wshadow -Wconversion` with `-std=c++17`, and also under MinGW-w64 for Windows. No linker errors.

The final release ZIP was extracted into a clean folder and, from there, built (zero warnings with `-Werror`), tested with sanitizers (224/224) and built/tested with CMake + CTest (passed). The ZIP contains no build output and no `data/db/` folder.

### Checks per area (224 total)

| Area | Checks |
|---|---|
| Date utilities (leap years, invalid dates, month/year rollover, day differences) | 21 |
| Input validators (numbers, money, email, phone, ISBN, text length, control characters) | 38 |
| Interactive input (letters instead of numbers, empty input, out of range, end of input, CRLF) | 8 |
| CSV escaping and parsing | 10 |
| Book inventory (add, update, delete, search, sort, duplicates, invalid quantities) | 31 |
| Member management | 17 |
| Issue and return (availability, duplicates, double return, fines, configurable rate) | 32 |
| Reports and statistics (computed from stored records) | 14 |
| Persistence and data integrity (restart, special characters, ID counters) | 14 |
| Missing, empty and corrupted files (and bad settings, BOM/CRLF, very long text) | 21 |
| Rollback when saving fails | 3 |
| Sample data import | 5 |
| Console interface driven by scripted keyboard input | 10 |

### Edge cases covered by automated tests

Empty database; invalid IDs; duplicate ISBN / duplicate member email (case-insensitive); negative and zero quantities; empty names; special characters (quotes, commas, ampersands, accented letters); 100 vs 101 character text and a 5,000-character field in a data file; invalid dates (Feb 29 in non-leap years, month 13, April 31); invalid menu input (letters, empty, out of range); missing files; zero-byte files; malformed lines (wrong field count, broken quotes, negative copies, available > total, invalid ISBN/year); duplicate IDs in files; active loan referring to a missing book; wrong stored available-copy counts (repaired); unusable data directory; failed save (state rolled back); end of input stream (no infinite loop).

### Data-integrity checks

Stock decreases on issue and increases on return; failed operations never change stock; available copies never exceed total copies (enforced by `Book` and tested); members and books with active loans cannot be deleted; IDs stay unique and are never reused after deletions or restarts; returned loans are not counted as issued; data is identical after restarting the program; the original of a corrupted file is preserved byte-for-byte as `*.corrupt.bak`.

### Does the test suite detect bugs? (mutation check)

Three deliberate bugs were temporarily inserted into `Library.cpp` to see whether the tests notice: (1) fine ignoring the configured rate - 2 checks failed; (2) returns not restoring stock - 5 checks failed; (3) allowing deletion of members with active loans - 4 checks failed. The code was restored afterwards and the suite passed 224/224 again.

### Manual end-to-end sessions with the real program (piped keyboard input)

Run on Linux against a temporary data folder: import sample data, issue three books, dashboard, restart, back-dated loan shown as OVERDUE with correct fine (25 days x 0.50 = 12.50), return with fine recorded, second return of the same transaction refused, letters entered as menu choice, input stream closed in the middle of a prompt (clean exit, exit code 0), corrupted line appended to `books.csv` (warning shown, original backed up), `--help`, and an unusable data folder (clear error, exit code 1). The Windows .exe was also run under Wine: sample import, issue, dashboard, restart, data still present.

## 4. NOT TESTED / known limitations

- **NOT TESTED:** running on real Windows 10 or 11 (only under Wine).
- **NOT TESTED:** `build.bat` and `run.bat` (Windows batch files cannot be executed in the development environment; they are short and use the same compiler flags as the commands above, but have never been run).
- **NOT TESTED:** the Microsoft Visual C++ (MSVC) compiler path in `build.bat` and `CMakeLists.txt`.
- **NOT TESTED:** GCC versions other than 13.x, Clang, macOS.
- **NOT TESTED:** display of accented/non-ASCII characters in the Windows console (data is stored correctly as UTF-8; display depends on the console code page).
- **NOT TESTED:** performance with very large data sets, and two copies of the program running at the same time on the same data folder (not supported - last writer wins).
- Overdue-fine tests use explicit dates; the "today" shortcut is tested only for returning a valid date.
- Saving writes four files one after another; each file is replaced atomically but the four together are not one transaction. Available-copy counts are derived data and are repaired from the loan records at load time, which covers the realistic failure case (tested with inconsistent files).
