# Uploading this project to GitHub

## Before you upload (5 minutes)
1. Replace `[Your Name]` in `LICENSE` and in the "Author" section of `README.md`. Replace `[your repository link]` in `docs/CV_PROJECT_DESCRIPTION.md` after you know the link.
2. Build and run it on your own computer once (`build.bat`, then `build.bat test`, then `run.bat`) and fix the "NOT TESTED" Windows items in `docs/TESTING.md` honestly: write what you ran and what happened. If something fails, tell me the error message.
3. Take 3 screenshots (Windows key + Shift + S), save them in `docs/screenshots/` and replace the placeholder lines in the README with image links, for example `![Main menu](docs/screenshots/main-menu.png)`.
4. Make sure `data/db/` does not exist or is empty (it is ignored by `.gitignore` anyway) so that no personal records are uploaded.

## Step by step
1. Install Git for Windows from https://git-scm.com/ and create a free account at https://github.com/.
2. On GitHub click **New repository**. Name: `Library-Management-System`. Description: `Menu-driven C++17 library management system with CSV persistence and automated tests`. Choose **Public**. Do **not** tick "Add a README", ".gitignore" or "license" (the project already has them). Click **Create repository**.
3. Open the project folder in VS Code, open a terminal and run (replace `YOUR-USERNAME`):

```
git init
git add .
git status
git commit -m "Initial commit: Library Management System (C++17)"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/Library-Management-System.git
git push -u origin main
```
If Git asks who you are, run once:
```
git config --global user.name "Your Name"
git config --global user.email "you@example.com"
```
When pushing, GitHub opens a browser sign-in window (or asks for a personal access token); follow the prompts.

4. Check `git status` before committing: there must be **no** `build/` folder, `.exe` files or `data/db/` in the list.
5. Open your repository page and confirm the README displays correctly.

## After uploading
- Add topics on the repository page: `cpp`, `cpp17`, `object-oriented-programming`, `library-management-system`, `console-application`, `cmake`.
- Pin the repository on your GitHub profile and put the link in your CV.
- Optional: create a Release (Releases > Draft a new release) and attach the `.exe` built on your own computer.
- Later updates: `git add .`, `git commit -m "describe the change"`, `git push`.
