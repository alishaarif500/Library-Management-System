# Features

Every feature listed here is implemented and covered by the automated tests (see TESTING.md).

## Book inventory
- Add books; IDs are generated automatically (1, 2, 3, ...) and never reused.
- Stored fields: ISBN, title, author, publisher, category, publication year, total copies, available copies.
- ISBN accepts 10 or 13 characters with optional hyphens/spaces; stored without separators. Duplicate ISBNs are rejected.
- Quantities: total copies 1-100000; available copies are always between 0 and total.
- Update any field (press Enter to keep the old value). Total copies cannot be set below the number of copies currently issued.
- Delete a book only when no copy is issued; confirmation is required. Loan history is kept.
- Display all books; sort by title (A-Z, case-insensitive) or by publication year; totals of titles and copies.

## Members
- Register members with auto-generated ID, full name, contact number, email and registration date.
- Phone: 7-15 digits (spaces, hyphens, parentheses, leading + allowed). Email must look like `name@domain.tld`. Duplicate emails (case-insensitive) are rejected.
- Update details; delete only when the member has no active loans (confirmation required).

## Issue and return
- Issue checks: book exists, member exists, a copy is available, the same member does not already hold the same book.
- Transaction ID is generated automatically; due date = issue date + loan period (default 14 days, configurable 1-365).
- Return by transaction ID; double returns are refused; return date cannot be earlier than the issue date.
- Overdue days = return date - due date (minimum 0). Fine = overdue days x daily rate (default 0.50, configurable 0.00-1000.00). The fine is stored with the transaction.
- Complete history of all loans is kept and can be listed.

## Search
Books by ID, title, author, ISBN, category (partial, case-insensitive text); members by ID and name; transactions by ID.

## Reports and statistics
Total titles, total/available/issued copies, members, active loans, returned loans, overdue loans, outstanding fines (fines accrued so far on overdue books still out), fines recorded on returned books, most borrowed books (top 5; shows "not enough history" when there are no loans). All values are computed from the stored records.

## Persistence and safety
- Files: `books.csv`, `members.csv`, `transactions.csv`, `settings.ini` in `data/db/` (created automatically).
- Saved after every change; saves are atomic (temp file + rename); if saving fails the change is rolled back.
- Loading validates every record. Bad lines are skipped with a warning and the original file is copied to `*.corrupt.bak` before anything is overwritten.
- Duplicate IDs/ISBNs/emails in files are dropped with a warning; available-copy counts are repaired from loan records.
- Special characters (commas, quotes, accents) are stored using standard CSV quoting.

## Interface
Numbered menus, consistent headings, `[OK]`, `[ERROR]` and `[!]` messages, confirmation before deleting, no crash or endless loop on wrong input or when the input ends.
