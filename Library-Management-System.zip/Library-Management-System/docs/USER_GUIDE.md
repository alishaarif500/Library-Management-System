# User Guide

## Starting
Run `run.bat` (or `build\LibraryManagementSystem.exe`) from the project folder. Use the number keys and Enter. In every submenu `0` returns to the previous menu; in the main menu `0` exits. Data is saved after every change, so there is no separate "save" step.

If you type something invalid (letters, empty text, a number out of range) the program explains the problem and asks again.

## First steps
1. **8 Settings > 4 Import sample data** - loads 12 example books and 6 members. This only works while the library is empty, and the program must be started from the project folder.
2. Or add your own: **3 Member Management > 1** and **2 Book Inventory > 1**.

## Daily work
| Task | Menu path | Notes |
|---|---|---|
| Add a book | 2 > 1 | ISBN has 10 or 13 characters, hyphens allowed |
| Change a book | 2 > 2 | Press Enter to keep a value |
| Delete a book | 2 > 3 | Refused while copies are issued; asks for confirmation |
| List/sort books | 2 > 4 / 5 / 6 | all / by title / by year |
| Register a member | 3 > 1 | Needs name, phone (7-15 digits), valid email |
| Issue a book | 4 | Enter Book ID and Member ID; write down the Transaction ID |
| Return a book | 5 > 1 | Enter the Transaction ID; overdue days and fine are shown |
| See who has books | 5 > 2 | Active transactions; overdue ones are marked OVERDUE |
| Search | 6 | By ID, text, ISBN, category, member name or transaction ID |
| Reports | 7 | Summary, overdue list, most borrowed, active loans |
| Change rules | 8 | Loan period in days, fine per day (for example 0.50) |

## Rules to remember
- A member cannot borrow the same book twice at the same time.
- A book with no available copies cannot be issued.
- A book or member with active loans cannot be deleted.
- Fine = number of days after the due date x fine per day. A book returned on the due date has no fine.
- Changing the loan period or fine rate affects new loans/returns only (fines are calculated when the book is returned).

## Where is my data?
In `data\db\` next to the program: `books.csv`, `members.csv`, `transactions.csv`, `settings.ini`. They are plain text and can be opened in Excel or Notepad for viewing; edit them only when the program is closed. Back up by copying the folder. If the program reports skipped lines at start-up, your original file was saved as `*.corrupt.bak` in the same folder.

## Troubleshooting
| Problem | Solution |
|---|---|
| `g++` is not recognised | Install MinGW-w64 and add its `bin` folder to PATH, then open a new terminal |
| "Sample files not found" | Start the program from the project folder (use `run.bat`) |
| Accented letters look wrong | Run `chcp 65001` in the console before starting; the stored data is correct |
| Warning about skipped lines | Open `*.corrupt.bak`, fix lines if you want to recover them |
