# CV Project Description and Interview Preparation

## A. CV-ready title

**Library Management System | C++17**
GitHub: `[your repository link]`

## B. CV bullet points (all statements match the implemented and tested code)

- Designed and implemented a modular C++17 console application (about 2,300 lines in 10 source modules) for managing books, members, loans and returns, using encapsulated entity classes and separate business-logic, storage, reporting and user-interface layers.
- Built a persistent storage layer with standard-library file I/O: CSV serialization with quoting for special characters, atomic write-then-rename saves, validation of every record on load, automatic backup of corrupted files, and rollback of in-memory changes when saving fails.
- Implemented loan workflows with availability and duplicate-loan checks, configurable loan period and overdue-fine rules, O(1) ID lookup with `std::unordered_map`, and `std::sort`-based sorting and search, plus reports computed from stored records.
- Wrote an automated test suite of 224 checks (including scripted tests of the console menus), verified with GCC and AddressSanitizer/UBSan, a CMake/CTest build, and a MinGW-w64 Windows build; checked test sensitivity by deliberately injecting bugs.

Shorter version (if space is tight): *Built a C++17 library management system with OOP design, CSV-based persistence, input validation, overdue-fine calculation and 224 automated tests; published on GitHub.*

## C. Interview preparation

Use these answers as a study guide. Read the code mentioned in each answer so you can explain it in your own words and show it on screen.

**1. Why did you develop this project?**
To practise building a complete application rather than isolated exercises: requirements, modular design, persistent storage, validation, and testing. A library is a familiar domain with real rules (stock, loans, deadlines), so the logic is easy to explain. It is a software-engineering foundations project, not an AI project.

**2. Which OOP principles did you use?**
Encapsulation: `Book` hides its counts and only changes them through `checkOut()`, `checkIn()` and `update()`, so available copies can never exceed total copies. Abstraction/separation of concerns: `ConsoleUI` knows nothing about files, `FileManager` knows nothing about rules, `Library` coordinates. I deliberately did not use inheritance, because there is no natural "is-a" hierarchy here and adding one would be over-engineering.

**3. What does each class do?**
`Book`, `Member`, `Transaction` - data plus invariants. `Library` - all business rules and the in-memory database. `FileManager` - reading/writing CSV and settings. `ReportManager` - statistics. `InputValidator` - validation and safe input. `DateUtils` - date arithmetic. `ConsoleUI` - menus. `main` - start-up.

**4. How does file handling work?**
Each save writes `books.csv`, `members.csv`, `transactions.csv`, `settings.ini`. A file is first written to `name.tmp` and then renamed over the original, so a crash cannot leave a half-written file. On load every line is parsed and validated; bad lines are skipped with a warning and the original is copied to `.corrupt.bak`. Fields with commas or quotes use standard CSV quoting.

**5. Why those data structures?**
`std::vector` for storage (simple, cache-friendly, easy to sort/print); `std::unordered_map<int,size_t>` as an ID index for O(1) lookups; `std::set` for duplicate detection while loading; `std::sort` for sorted views. For a few thousand records the simple design is correct and fast enough; for a large system I would use a database with indexes.

**6. How do searching and sorting work?**
Text search is a case-insensitive substring scan (O(n)), which is fine at this size. ID search uses the hash index (O(1) average). Sorting copies the vector and uses `std::sort` (O(n log n)) with a case-insensitive comparison and the ID as tie-breaker so the order is deterministic.

**7. How is transaction management handled?**
Issuing checks the book, the member, the date, availability and duplicates, then inside one `commit` it creates the transaction and reduces the available copies. Returning checks the transaction is active, computes overdue days and fine, closes the transaction and restores a copy. `commit` copies the state first and restores it if anything fails, including a failed save, so records never end up half-updated.

**8. How do you validate data?**
At three levels: the UI re-prompts on invalid input; `Library` validates again (it never trusts the UI); entity constructors enforce invariants; loaders validate every record read from disk. The rule "validate at the boundary and again at the core" avoids relying on a single check.

**9. How does error handling work?**
Rule violations throw `LibraryError` with a user-friendly message; the UI catches it, prints it and returns to the menu. Unexpected situations (cannot create the data folder) become a clear message and exit code 1. End of input throws `InputClosedError`, so the program exits cleanly instead of looping forever.

**10. How does the fine calculation work and why integers?**
Fine = overdue days x daily rate, with overdue days = max(0, return date - due date). The rate is stored as integer hundredths (50 = 0.50) because floating-point numbers cannot represent most decimal amounts exactly.

**11. Why are "available copies" repaired when loading?**
Available copies are derived data (total minus active loans). If files were edited by hand or a save was interrupted between files, the loan records are treated as the truth and the count is corrected, with a warning.

**12. What was your testing strategy?**
A self-written test program with 224 checks: unit tests for utilities, tests of every business rule including the failure paths, persistence tests that create a new `Library` object to simulate a restart, corruption tests with hand-made bad files, and tests that drive the real menus with scripted input via string streams. Tests use temporary folders. I ran them with sanitizers, and I injected three deliberate bugs to confirm the tests actually fail when the code is wrong.

**13. Which design decisions would you defend or reconsider?**
Defend: commit-with-rollback, derived stock counts, integer money, ISO date strings, no inheritance. Reconsider: rewriting whole files on every change (fine here, not at scale); the four files are not saved as one transaction (SQLite would solve that); no file locking, so two instances could overwrite each other.

**14. What are the limitations?**
Single user, no authentication, no per-member loan limit, fines are not tracked as paid or unpaid, ISBN check digits are not verified, text limits are in bytes, and it was verified on Linux and under Wine but not yet on a native Windows machine (stated in `docs/TESTING.md`).

**15. What would you improve next?**
Replace CSV with SQLite (transactions, indexes), add renewals/reservations and loan limits, add a GUI or web front end, add continuous integration (GitHub Actions) and a standard test framework (GoogleTest/Catch2), and generate reports as files.

## D. Academic relevance (honest assessment)

This project shows solid programming fundamentals that Computer Science and AI programmes expect: object-oriented design, data structures and algorithms in practice, file I/O, defensive input handling, testing and documentation, and use of version control. It also shows the discipline of verifying work rather than just writing it.

It is **not** an Artificial Intelligence, Machine Learning or research project, and should not be described as one. For a Master's application in AI it is best presented as a supporting software-engineering project alongside your ML/NLP projects and any research interests, and it is most relevant to internship and junior engineering applications. It contains no performance claims, users or publications; do not add any.

**Integrity note:** be ready to explain every module in your own words and to modify the code during an interview. If a programme or employer asks how the project was built, answer truthfully, including any use of AI assistance, and spend time reading and re-running the tests so that the project really is understood by you.
