#include "ConsoleUI.h"

#include <iomanip>

#include "DateUtils.h"
#include "InputValidator.h"
#include "ReportManager.h"

namespace {

std::string cut(const std::string& text, std::size_t width) {
    return text.size() <= width ? text : text.substr(0, width - 2) + "..";
}

const char* kLine = "------------------------------------------------------------------------------------------";

}  // namespace

ConsoleUI::ConsoleUI(Library& library, std::istream& in, std::ostream& out)
    : library_(library), in_(in), out_(out) {}

// ------------------------------------------------------------------------------------------
// Helpers
// ------------------------------------------------------------------------------------------

void ConsoleUI::header(const std::string& title) {
    out_ << "\n==========================================================================================\n"
         << "  " << title << "\n"
         << "==========================================================================================\n";
}

int ConsoleUI::showMenu(const std::string& title, const std::vector<std::string>& items,
                        const std::string& zeroLabel) {
    header(title);
    for (std::size_t i = 0; i < items.size(); ++i) out_ << "  " << (i + 1) << ". " << items[i] << "\n";
    out_ << "  0. " << zeroLabel << "\n" << kLine << "\n";
    return InputValidator::readInt("Enter your choice: ", 0, static_cast<int>(items.size()), in_, out_);
}

void ConsoleUI::pause() { InputValidator::readLine("\nPress Enter to continue...", in_, out_); }

void ConsoleUI::runAction(const std::function<void()>& action) {
    try {
        action();
    } catch (const InputClosedError&) {
        throw;  // end of input must reach main() so the program can exit
    } catch (const std::exception& e) {
        out_ << "\n  [ERROR] " << e.what() << "\n";
    }
}

int ConsoleUI::askId(const std::string& prompt) {
    return InputValidator::readInt(prompt + " (0 to cancel): ", 0, 2000000000, in_, out_);
}

void ConsoleUI::printBooks(const std::vector<Book>& books) {
    if (books.empty()) { out_ << "  (no books found)\n"; return; }
    out_ << std::left << std::setw(6) << "ID" << std::setw(14) << "ISBN" << std::setw(28) << "Title"
         << std::setw(20) << "Author" << std::setw(14) << "Category" << std::setw(6) << "Year"
         << "Avail/Total\n" << kLine << "\n";
    for (const Book& b : books) {
        out_ << std::left << std::setw(6) << b.id() << std::setw(14) << b.isbn() << std::setw(28)
             << cut(b.title(), 27) << std::setw(20) << cut(b.author(), 19) << std::setw(14)
             << cut(b.category(), 13) << std::setw(6) << b.year() << b.availableCopies() << "/"
             << b.totalCopies() << "\n";
    }
    out_ << "  " << books.size() << " record(s).\n";
}

void ConsoleUI::printMembers(const std::vector<Member>& members) {
    if (members.empty()) { out_ << "  (no members found)\n"; return; }
    out_ << std::left << std::setw(6) << "ID" << std::setw(26) << "Name" << std::setw(18) << "Phone"
         << std::setw(30) << "Email" << "Registered\n" << kLine << "\n";
    for (const Member& m : members) {
        out_ << std::left << std::setw(6) << m.id() << std::setw(26) << cut(m.name(), 25) << std::setw(18)
             << cut(m.phone(), 17) << std::setw(30) << cut(m.email(), 29) << m.registrationDate() << "\n";
    }
    out_ << "  " << members.size() << " record(s).\n";
}

void ConsoleUI::printTransactions(const std::vector<Transaction>& txs) {
    if (txs.empty()) { out_ << "  (no transactions found)\n"; return; }
    out_ << std::left << std::setw(6) << "TxID" << std::setw(24) << "Book" << std::setw(20) << "Member"
         << std::setw(12) << "Issued" << std::setw(12) << "Due" << std::setw(12) << "Returned"
         << std::setw(8) << "Late" << std::setw(8) << "Fine" << "Status\n" << kLine << "\n";
    const std::string today = DateUtils::today();
    for (const Transaction& t : txs) {
        const Book* b = library_.findBook(t.bookId());
        const Member* m = library_.findMember(t.memberId());
        const std::string book = std::to_string(t.bookId()) + " " + (b ? b->title() : "[deleted]");
        const std::string member = std::to_string(t.memberId()) + " " + (m ? m->name() : "[deleted]");
        const long late = library_.overdueDays(t, today);
        const std::string status = t.isActive() ? (late > 0 ? "OVERDUE" : "Active") : "Returned";
        out_ << std::left << std::setw(6) << t.id() << std::setw(24) << cut(book, 23) << std::setw(20)
             << cut(member, 19) << std::setw(12) << t.issueDate() << std::setw(12) << t.dueDate()
             << std::setw(12) << (t.isActive() ? "-" : t.returnDate()) << std::setw(8) << late
             << std::setw(8) << formatCents(library_.accruedFineCents(t, today)) << status << "\n";
    }
    out_ << "  " << txs.size() << " record(s).\n";
}

BookData ConsoleUI::promptBookData(const Book* current) {
    using namespace InputValidator;
    const Checker isbnCheck = [](const std::string& v, std::string& err) {
        if (!normalizeIsbn(v).empty()) return true;
        err = "ISBN must have 10 digits (last may be X) or 13 digits; hyphens allowed.";
        return false;
    };
    const Checker textCheck = [](const std::string& v, std::string& err) {
        if (isValidRequiredText(v)) return true;
        err = "Please enter 1-100 printable characters.";
        return false;
    };
    BookData d;
    if (!current) {  // new book: every field is required
        d.isbn = readValidated("ISBN (10 or 13 digits): ", isbnCheck, in_, out_);
        d.title = readValidated("Title: ", textCheck, in_, out_);
        d.author = readValidated("Author: ", textCheck, in_, out_);
        d.publisher = readValidated("Publisher: ", textCheck, in_, out_);
        d.category = readValidated("Category: ", textCheck, in_, out_);
        d.year = readInt("Publication year (1000-2100): ", 1000, 2100, in_, out_);
        d.totalCopies = readInt("Total copies (1-100000): ", 1, 100000, in_, out_);
    } else {         // update: Enter keeps the current value
        out_ << "  (press Enter to keep the current value)\n";
        d.isbn = readOptionalText("ISBN [" + current->isbn() + "]: ", current->isbn(), isbnCheck, in_, out_);
        d.title = readOptionalText("Title [" + current->title() + "]: ", current->title(), textCheck, in_, out_);
        d.author = readOptionalText("Author [" + current->author() + "]: ", current->author(), textCheck, in_, out_);
        d.publisher = readOptionalText("Publisher [" + current->publisher() + "]: ", current->publisher(), textCheck, in_, out_);
        d.category = readOptionalText("Category [" + current->category() + "]: ", current->category(), textCheck, in_, out_);
        d.year = readOptionalInt("Year [" + std::to_string(current->year()) + "]: ", current->year(), 1000, 2100, in_, out_);
        d.totalCopies = readOptionalInt("Total copies [" + std::to_string(current->totalCopies()) + "]: ",
                                        current->totalCopies(), 1, 100000, in_, out_);
    }
    return d;
}

MemberData ConsoleUI::promptMemberData(const Member* current) {
    using namespace InputValidator;
    const Checker nameCheck = [](const std::string& v, std::string& err) {
        if (isValidRequiredText(v)) return true;
        err = "Name must be 1-100 printable characters.";
        return false;
    };
    const Checker phoneCheck = [](const std::string& v, std::string& err) {
        if (isValidPhone(v)) return true;
        err = "Enter 7-15 digits (spaces, -, (), and a leading + are allowed).";
        return false;
    };
    const Checker emailCheck = [](const std::string& v, std::string& err) {
        if (isValidEmail(v)) return true;
        err = "Enter a valid email address, for example name@example.com.";
        return false;
    };
    MemberData d;
    if (!current) {
        d.name = readValidated("Full name: ", nameCheck, in_, out_);
        d.phone = readValidated("Contact number: ", phoneCheck, in_, out_);
        d.email = readValidated("Email: ", emailCheck, in_, out_);
    } else {
        out_ << "  (press Enter to keep the current value)\n";
        d.name = readOptionalText("Full name [" + current->name() + "]: ", current->name(), nameCheck, in_, out_);
        d.phone = readOptionalText("Contact number [" + current->phone() + "]: ", current->phone(), phoneCheck, in_, out_);
        d.email = readOptionalText("Email [" + current->email() + "]: ", current->email(), emailCheck, in_, out_);
    }
    return d;
}

// ------------------------------------------------------------------------------------------
// Main loop
// ------------------------------------------------------------------------------------------

void ConsoleUI::run() {
    out_ << "\n  LIBRARY MANAGEMENT SYSTEM\n  Today's date: " << DateUtils::today() << "\n";
    while (true) {
        const int choice = showMenu("MAIN MENU",
            {"Dashboard", "Book Inventory", "Member Management", "Issue a Book", "Return a Book",
             "Search Records", "Reports and Statistics", "Settings", "Help and About"},
            "Exit");
        switch (choice) {
            case 1: dashboard(); break;
            case 2: bookMenu(); break;
            case 3: memberMenu(); break;
            case 4: issueScreen(); break;
            case 5: returnMenu(); break;
            case 6: searchMenu(); break;
            case 7: reportsMenu(); break;
            case 8: settingsMenu(); break;
            case 9: helpScreen(); break;
            case 0:
                library_.save();  // every change is already saved; this is a final safety save
                out_ << "\n  All data saved. Goodbye!\n";
                return;
        }
    }
}

// ------------------------------------------------------------------------------------------
// Dashboard
// ------------------------------------------------------------------------------------------

void ConsoleUI::dashboard() {
    header("DASHBOARD");
    ReportManager reports(library_);
    reports.printSummary(out_);
    const std::vector<Transaction> overdue = library_.overdueTransactions();
    if (!overdue.empty()) {
        out_ << "\n  Overdue loans needing attention:\n";
        printTransactions(overdue);
    }
    pause();
}

// ------------------------------------------------------------------------------------------
// Books
// ------------------------------------------------------------------------------------------

void ConsoleUI::bookMenu() {
    while (true) {
        const int choice = showMenu("BOOK INVENTORY",
            {"Add a new book", "Update a book", "Delete a book", "Display all books",
             "Display books sorted by title (A-Z)", "Display books sorted by publication year",
             "Show totals (books and available copies)"},
            "Back to main menu");
        if (choice == 0) return;
        runAction([&] {
            switch (choice) {
                case 1: addBook(); break;
                case 2: updateBook(); break;
                case 3: deleteBook(); break;
                case 4: header("ALL BOOKS"); printBooks(library_.books()); break;
                case 5: header("BOOKS SORTED BY TITLE"); printBooks(library_.booksSortedByTitle()); break;
                case 6: header("BOOKS SORTED BY YEAR"); printBooks(library_.booksSortedByYear()); break;
                case 7: {
                    ReportManager r(library_);
                    const Statistics s = r.compute();
                    header("BOOK TOTALS");
                    out_ << "  Titles registered : " << s.totalBookTitles << "\n"
                         << "  Total copies      : " << s.totalCopies << "\n"
                         << "  Available copies  : " << s.availableCopies << "\n"
                         << "  Issued copies     : " << s.issuedCopies << "\n";
                    break;
                }
            }
        });
        pause();
    }
}

void ConsoleUI::addBook() {
    header("ADD A NEW BOOK");
    const BookData data = promptBookData(nullptr);
    const int id = library_.addBook(data);
    out_ << "\n  [OK] Book added with ID " << id << ".\n";
}

void ConsoleUI::updateBook() {
    header("UPDATE A BOOK");
    const int id = askId("Book ID");
    if (id == 0) return;
    const Book* book = library_.findBook(id);
    if (!book) throw LibraryError("Book ID " + std::to_string(id) + " does not exist.");
    const BookData data = promptBookData(book);
    library_.updateBook(id, data);
    out_ << "\n  [OK] Book " << id << " updated.\n";
}

void ConsoleUI::deleteBook() {
    header("DELETE A BOOK");
    const int id = askId("Book ID");
    if (id == 0) return;
    const Book* book = library_.findBook(id);
    if (!book) throw LibraryError("Book ID " + std::to_string(id) + " does not exist.");
    out_ << "  \"" << book->title() << "\" by " << book->author() << "\n";
    if (!InputValidator::confirm("Delete this book permanently?", in_, out_)) {
        out_ << "  Cancelled.\n";
        return;
    }
    library_.deleteBook(id);
    out_ << "\n  [OK] Book " << id << " deleted.\n";
}

// ------------------------------------------------------------------------------------------
// Members
// ------------------------------------------------------------------------------------------

void ConsoleUI::memberMenu() {
    while (true) {
        const int choice = showMenu("MEMBER MANAGEMENT",
            {"Register a new member", "Update member details", "Delete a member",
             "Display all members"},
            "Back to main menu");
        if (choice == 0) return;
        runAction([&] {
            switch (choice) {
                case 1: addMember(); break;
                case 2: updateMember(); break;
                case 3: deleteMember(); break;
                case 4: header("ALL MEMBERS"); printMembers(library_.members()); break;
            }
        });
        pause();
    }
}

void ConsoleUI::addMember() {
    header("REGISTER A NEW MEMBER");
    const MemberData data = promptMemberData(nullptr);
    const int id = library_.addMember(data);
    out_ << "\n  [OK] Member registered with ID " << id << " on " << DateUtils::today() << ".\n";
}

void ConsoleUI::updateMember() {
    header("UPDATE MEMBER DETAILS");
    const int id = askId("Member ID");
    if (id == 0) return;
    const Member* member = library_.findMember(id);
    if (!member) throw LibraryError("Member ID " + std::to_string(id) + " does not exist.");
    const MemberData data = promptMemberData(member);
    library_.updateMember(id, data);
    out_ << "\n  [OK] Member " << id << " updated.\n";
}

void ConsoleUI::deleteMember() {
    header("DELETE A MEMBER");
    const int id = askId("Member ID");
    if (id == 0) return;
    const Member* member = library_.findMember(id);
    if (!member) throw LibraryError("Member ID " + std::to_string(id) + " does not exist.");
    out_ << "  " << member->name() << " (" << member->email() << ")\n";
    if (!InputValidator::confirm("Delete this member permanently?", in_, out_)) {
        out_ << "  Cancelled.\n";
        return;
    }
    library_.deleteMember(id);
    out_ << "\n  [OK] Member " << id << " deleted.\n";
}

// ------------------------------------------------------------------------------------------
// Issue / return
// ------------------------------------------------------------------------------------------

void ConsoleUI::issueScreen() {
    runAction([&] {
        header("ISSUE A BOOK");
        const int bookId = askId("Book ID");
        if (bookId == 0) return;
        const int memberId = askId("Member ID");
        if (memberId == 0) return;
        const Transaction tx = library_.issueBook(bookId, memberId);
        const Book* book = library_.findBook(bookId);
        const Member* member = library_.findMember(memberId);
        out_ << "\n  [OK] Book issued.\n"
             << "  Transaction ID : " << tx.id() << "\n"
             << "  Book           : " << (book ? book->title() : "") << "\n"
             << "  Member         : " << (member ? member->name() : "") << "\n"
             << "  Issue date     : " << tx.issueDate() << "\n"
             << "  Due date       : " << tx.dueDate() << "\n";
    });
    pause();
}

void ConsoleUI::returnBook() {
    header("RETURN A BOOK BY TRANSACTION ID");
    const int id = askId("Transaction ID");
    if (id == 0) return;
    const Transaction tx = library_.returnBook(id);
    const long late = library_.overdueDays(tx);
    out_ << "\n  [OK] Book returned on " << tx.returnDate() << ".\n"
         << "  Due date     : " << tx.dueDate() << "\n"
         << "  Overdue days : " << late << "\n"
         << "  Fine         : " << formatCents(tx.fineCents()) << "  (rate "
         << formatCents(library_.settings().finePerDayCents) << " per day)\n";
}

void ConsoleUI::returnMenu() {
    while (true) {
        const int choice = showMenu("RETURN A BOOK",
            {"Return a book (by transaction ID)", "List active (unreturned) transactions",
             "View complete transaction history"},
            "Back to main menu");
        if (choice == 0) return;
        runAction([&] {
            switch (choice) {
                case 1: returnBook(); break;
                case 2: header("ACTIVE TRANSACTIONS"); printTransactions(library_.activeTransactions()); break;
                case 3: header("TRANSACTION HISTORY"); printTransactions(library_.transactions()); break;
            }
        });
        pause();
    }
}

// ------------------------------------------------------------------------------------------
// Search
// ------------------------------------------------------------------------------------------

void ConsoleUI::searchMenu() {
    while (true) {
        const int choice = showMenu("SEARCH RECORDS",
            {"Book by ID", "Book by title", "Book by author", "Book by ISBN", "Book by category",
             "Member by ID", "Member by name", "Transaction by ID"},
            "Back to main menu");
        if (choice == 0) return;
        runAction([&] {
            if (choice == 1) {
                const int id = askId("Book ID");
                if (id == 0) return;
                std::vector<Book> found;
                if (const Book* b = library_.findBook(id)) found.push_back(*b);
                printBooks(found);
            } else if (choice >= 2 && choice <= 5) {
                static const char* labels[] = {"", "", "title", "author", "ISBN", "category"};
                const std::string text = InputValidator::readValidated(
                    std::string("Search text (") + labels[choice] + "): ",
                    [](const std::string& v, std::string& err) {
                        if (!v.empty() && v.size() <= InputValidator::kMaxTextLength) return true;
                        err = "Enter 1-100 characters.";
                        return false;
                    }, in_, out_);
                if (choice == 2) printBooks(library_.searchBooksByTitle(text));
                else if (choice == 3) printBooks(library_.searchBooksByAuthor(text));
                else if (choice == 4) printBooks(library_.searchBooksByIsbn(text));
                else printBooks(library_.searchBooksByCategory(text));
            } else if (choice == 6) {
                const int id = askId("Member ID");
                if (id == 0) return;
                std::vector<Member> found;
                if (const Member* m = library_.findMember(id)) found.push_back(*m);
                printMembers(found);
            } else if (choice == 7) {
                const std::string text = InputValidator::readValidated("Name contains: ",
                    [](const std::string& v, std::string& err) {
                        if (!v.empty() && v.size() <= InputValidator::kMaxTextLength) return true;
                        err = "Enter 1-100 characters.";
                        return false;
                    }, in_, out_);
                printMembers(library_.searchMembersByName(text));
            } else {
                const int id = askId("Transaction ID");
                if (id == 0) return;
                std::vector<Transaction> found;
                if (const Transaction* t = library_.findTransaction(id)) found.push_back(*t);
                printTransactions(found);
            }
        });
        pause();
    }
}

// ------------------------------------------------------------------------------------------
// Reports, settings, help
// ------------------------------------------------------------------------------------------

void ConsoleUI::reportsMenu() {
    while (true) {
        const int choice = showMenu("REPORTS AND STATISTICS",
            {"Summary statistics", "Overdue books", "Most borrowed books", "All active transactions"},
            "Back to main menu");
        if (choice == 0) return;
        runAction([&] {
            ReportManager reports(library_);
            switch (choice) {
                case 1: header("SUMMARY STATISTICS"); reports.printSummary(out_); break;
                case 2: header("OVERDUE BOOKS"); printTransactions(library_.overdueTransactions()); break;
                case 3: header("MOST BORROWED BOOKS"); reports.printMostBorrowed(out_); break;
                case 4: header("ACTIVE TRANSACTIONS"); printTransactions(library_.activeTransactions()); break;
            }
        });
        pause();
    }
}

void ConsoleUI::importSamples() {
    header("IMPORT SAMPLE DATA");
    out_ << "  This loads example books and members (only possible when the library is empty).\n";
    if (!InputValidator::confirm("Import sample data now?", in_, out_)) return;
    std::size_t books = 0, members = 0;
    library_.importSampleData("data/sample_books.csv", "data/sample_members.csv", books, members);
    out_ << "\n  [OK] Imported " << books << " books and " << members << " members.\n";
}

void ConsoleUI::settingsMenu() {
    while (true) {
        const int choice = showMenu("SETTINGS",
            {"View current settings", "Change loan period (days)", "Change overdue fine per day",
             "Import sample data"},
            "Back to main menu");
        if (choice == 0) return;
        runAction([&] {
            const Settings& s = library_.settings();
            switch (choice) {
                case 1:
                    header("CURRENT SETTINGS");
                    out_ << "  Loan period        : " << s.loanPeriodDays << " days\n"
                         << "  Fine per day       : " << formatCents(s.finePerDayCents) << "\n"
                         << "  Data directory     : " << library_.dataDirectory() << "\n";
                    break;
                case 2: {
                    const int days = InputValidator::readInt("New loan period in days (1-365): ", 1, 365, in_, out_);
                    library_.setLoanPeriodDays(days);
                    out_ << "  [OK] Loan period set to " << days << " days (applies to new loans).\n";
                    break;
                }
                case 3: {
                    long long cents = 0;
                    InputValidator::readValidated("New fine per day, e.g. 0.50 (0-1000): ",
                        [&](const std::string& v, std::string& err) {
                            if (InputValidator::tryParseMoney(v, cents) && cents <= 100000) return true;
                            err = "Enter an amount like 0.50 or 2 (at most 2 decimals, max 1000).";
                            return false;
                        }, in_, out_);
                    library_.setFinePerDayCents(cents);
                    out_ << "  [OK] Fine per day set to " << formatCents(cents) << ".\n";
                    break;
                }
                case 4: importSamples(); break;
            }
        });
        pause();
    }
}

void ConsoleUI::helpScreen() {
    header("HELP AND ABOUT");
    out_ << "  Library Management System (C++17 console application)\n\n"
         << "  How to use:\n"
         << "   - Type the number of a menu item and press Enter. 0 always goes back / exits.\n"
         << "   - Register members first, add books, then use 'Issue a Book' with the Book ID\n"
         << "     and Member ID. Use 'Return a Book' with the Transaction ID printed at issue time.\n"
         << "   - Dates are the computer's local date. The due date is issue date + loan period.\n"
         << "   - Fine = overdue days x fine per day (both configurable in Settings).\n"
         << "   - Every change is saved immediately to the data folder: " << library_.dataDirectory() << "\n\n"
         << "  Start with 'Settings > Import sample data' to try the program with example records.\n";
    pause();
}
