#include "Library.h"

#include <algorithm>
#include <filesystem>
#include <set>

#include "FileManager.h"
#include "InputValidator.h"

namespace {

using InputValidator::toLower;

bool containsIgnoreCase(const std::string& haystack, const std::string& needle) {
    return toLower(haystack).find(toLower(needle)) != std::string::npos;
}

// Converts validation exceptions into LibraryError so callers handle a single error type.
template <typename F>
auto asLibraryError(F&& f) -> decltype(f()) {
    try {
        return f();
    } catch (const std::invalid_argument& e) {
        throw LibraryError(e.what());
    }
}

std::string withoutIsbnSeparators(const std::string& text) {
    std::string result;
    for (char c : InputValidator::trim(text)) {
        if (c != '-' && c != ' ') result += static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    }
    return result;
}

}  // namespace

Library::Library(std::string dataDirectory) : dataDirectory_(std::move(dataDirectory)) {}

std::string Library::path(const char* fileName) const {
    return (std::filesystem::path(dataDirectory_) / fileName).string();
}

void Library::rebuildIndexes() {
    bookIndex_.clear();
    memberIndex_.clear();
    transactionIndex_.clear();
    for (std::size_t i = 0; i < state_.books.size(); ++i) bookIndex_[state_.books[i].id()] = i;
    for (std::size_t i = 0; i < state_.members.size(); ++i) memberIndex_[state_.members[i].id()] = i;
    for (std::size_t i = 0; i < state_.transactions.size(); ++i)
        transactionIndex_[state_.transactions[i].id()] = i;
}

// ----------------------------------------------------------------------------------------
// Loading and saving
// ----------------------------------------------------------------------------------------

bool Library::installRecords(std::vector<Book> books, std::vector<Member> members,
                             std::vector<Transaction> txs, std::vector<std::string>& warnings) {
    bool dropped = false;
    State fresh;
    fresh.settings = state_.settings;
    fresh.counters = state_.counters;

    std::set<int> bookIds, memberIds, txIds;
    std::set<std::string> isbns, emails;
    for (Book& b : books) {
        if (!bookIds.insert(b.id()).second) {
            warnings.push_back("books: duplicate ID " + std::to_string(b.id()) + " skipped");
            dropped = true;
        } else if (!isbns.insert(b.isbn()).second) {
            warnings.push_back("books: duplicate ISBN " + b.isbn() + " (ID " + std::to_string(b.id()) + ") skipped");
            dropped = true;
        } else {
            fresh.books.push_back(std::move(b));
        }
    }
    for (Member& m : members) {
        if (!memberIds.insert(m.id()).second) {
            warnings.push_back("members: duplicate ID " + std::to_string(m.id()) + " skipped");
            dropped = true;
        } else if (!emails.insert(toLower(m.email())).second) {
            warnings.push_back("members: duplicate email " + m.email() + " (ID " + std::to_string(m.id()) + ") skipped");
            dropped = true;
        } else {
            fresh.members.push_back(std::move(m));
        }
    }
    for (Transaction& t : txs) {
        if (!txIds.insert(t.id()).second) {
            warnings.push_back("transactions: duplicate ID " + std::to_string(t.id()) + " skipped");
            dropped = true;
        } else if (t.isActive() && (!bookIds.count(t.bookId()) || !memberIds.count(t.memberId()))) {
            warnings.push_back("transactions: active loan " + std::to_string(t.id()) +
                               " refers to a missing book or member and was skipped");
            dropped = true;
        } else {
            fresh.transactions.push_back(std::move(t));
        }
    }

    // Available copies are derived data: total copies minus active loans. Repair on mismatch.
    std::unordered_map<int, int> active;
    for (const Transaction& t : fresh.transactions) if (t.isActive()) ++active[t.bookId()];
    for (Book& b : fresh.books) {
        const int issued = active.count(b.id()) ? active[b.id()] : 0;
        if (issued > b.totalCopies()) {
            warnings.push_back("books: ID " + std::to_string(b.id()) + " had more active loans than copies; total copies corrected");
            BookData d;
            d.isbn = b.isbn(); d.title = b.title(); d.author = b.author(); d.publisher = b.publisher();
            d.category = b.category(); d.year = b.year(); d.totalCopies = issued;
            b = Book(b.id(), d, 0);
        } else if (b.issuedCopies() != issued) {
            warnings.push_back("books: ID " + std::to_string(b.id()) + " available copies corrected from " +
                               std::to_string(b.availableCopies()) + " to " + std::to_string(b.totalCopies() - issued));
            b.setAvailableCopies(b.totalCopies() - issued);
        }
    }

    // Counters must be above every ID in use (including history), so IDs are never reused.
    for (const Book& b : fresh.books) fresh.counters.nextBookId = std::max(fresh.counters.nextBookId, b.id() + 1);
    for (const Member& m : fresh.members) fresh.counters.nextMemberId = std::max(fresh.counters.nextMemberId, m.id() + 1);
    for (const Transaction& t : fresh.transactions) {
        fresh.counters.nextTransactionId = std::max(fresh.counters.nextTransactionId, t.id() + 1);
        fresh.counters.nextBookId = std::max(fresh.counters.nextBookId, t.bookId() + 1);
        fresh.counters.nextMemberId = std::max(fresh.counters.nextMemberId, t.memberId() + 1);
    }
    state_ = std::move(fresh);
    rebuildIndexes();
    return dropped;
}

std::vector<std::string> Library::load() {
    std::vector<std::string> warnings;
    try {
        FileManager::ensureDirectory(dataDirectory_);
    } catch (const std::exception& e) {
        throw LibraryError(e.what());
    }
    const bool anyMissing = !FileManager::fileExists(path("books.csv")) ||
                            !FileManager::fileExists(path("members.csv")) ||
                            !FileManager::fileExists(path("transactions.csv")) ||
                            !FileManager::fileExists(path("settings.ini"));

    state_ = State();
    FileManager::loadSettings(path("settings.ini"), state_.settings, state_.counters, warnings);
    std::vector<Book> books = FileManager::loadBooks(path("books.csv"), warnings);
    std::vector<Member> members = FileManager::loadMembers(path("members.csv"), warnings);
    std::vector<Transaction> txs = FileManager::loadTransactions(path("transactions.csv"), warnings);
    const bool dropped = installRecords(std::move(books), std::move(members), std::move(txs), warnings);
    if (dropped) {  // keep a copy of the untouched files before anything is saved over them
        FileManager::backupFile(path("books.csv"));
        FileManager::backupFile(path("members.csv"));
        FileManager::backupFile(path("transactions.csv"));
        warnings.push_back("Some records were dropped. Copies of the original files were saved as *.corrupt.bak.");
    }
    if (anyMissing) save();  // create the missing files with headers/defaults
    return warnings;
}

void Library::save() const {
    try {
        FileManager::saveBooks(path("books.csv"), state_.books);
        FileManager::saveMembers(path("members.csv"), state_.members);
        FileManager::saveTransactions(path("transactions.csv"), state_.transactions);
        FileManager::saveSettings(path("settings.ini"), state_.settings, state_.counters);
    } catch (const std::exception& e) {
        throw LibraryError(std::string("Could not save data: ") + e.what());
    }
}

void Library::commit(const std::function<void()>& change) {
    State backup = state_;
    try {
        change();
        rebuildIndexes();
        save();
    } catch (...) {
        state_ = std::move(backup);
        rebuildIndexes();
        throw;
    }
}

// ----------------------------------------------------------------------------------------
// Lookups
// ----------------------------------------------------------------------------------------

const Book* Library::findBook(int id) const {
    const auto it = bookIndex_.find(id);
    return it == bookIndex_.end() ? nullptr : &state_.books[it->second];
}
const Member* Library::findMember(int id) const {
    const auto it = memberIndex_.find(id);
    return it == memberIndex_.end() ? nullptr : &state_.members[it->second];
}
const Transaction* Library::findTransaction(int id) const {
    const auto it = transactionIndex_.find(id);
    return it == transactionIndex_.end() ? nullptr : &state_.transactions[it->second];
}
Book* Library::findBookMutable(int id) { return const_cast<Book*>(findBook(id)); }
Member* Library::findMemberMutable(int id) { return const_cast<Member*>(findMember(id)); }
Transaction* Library::findTransactionMutable(int id) { return const_cast<Transaction*>(findTransaction(id)); }

bool Library::isbnInUse(const std::string& isbn, int exceptBookId) const {
    return std::any_of(state_.books.begin(), state_.books.end(),
                       [&](const Book& b) { return b.id() != exceptBookId && b.isbn() == isbn; });
}

bool Library::memberContactInUse(const MemberData& data, int exceptMemberId) const {
    const std::string email = toLower(InputValidator::trim(data.email));
    return std::any_of(state_.members.begin(), state_.members.end(), [&](const Member& m) {
        return m.id() != exceptMemberId && toLower(m.email()) == email;
    });
}

int Library::activeLoansForBook(int bookId) const {
    return static_cast<int>(std::count_if(state_.transactions.begin(), state_.transactions.end(),
        [&](const Transaction& t) { return t.isActive() && t.bookId() == bookId; }));
}
int Library::activeLoansForMember(int memberId) const {
    return static_cast<int>(std::count_if(state_.transactions.begin(), state_.transactions.end(),
        [&](const Transaction& t) { return t.isActive() && t.memberId() == memberId; }));
}

// ----------------------------------------------------------------------------------------
// Books
// ----------------------------------------------------------------------------------------

int Library::addBook(const BookData& data) {
    asLibraryError([&] { Book::validate(data); return 0; });
    const std::string isbn = InputValidator::normalizeIsbn(data.isbn);
    if (isbnInUse(isbn, 0)) throw LibraryError("A book with ISBN " + isbn + " already exists.");
    int id = 0;
    commit([&] {
        id = state_.counters.nextBookId++;
        state_.books.push_back(asLibraryError([&] { return Book(id, data, data.totalCopies); }));
    });
    return id;
}

void Library::updateBook(int id, const BookData& data) {
    if (!findBook(id)) throw LibraryError("Book ID " + std::to_string(id) + " does not exist.");
    asLibraryError([&] { Book::validate(data); return 0; });
    const std::string isbn = InputValidator::normalizeIsbn(data.isbn);
    if (isbnInUse(isbn, id)) throw LibraryError("Another book already uses ISBN " + isbn + ".");
    commit([&] { asLibraryError([&] { findBookMutable(id)->update(data); return 0; }); });
}

void Library::deleteBook(int id) {
    if (!findBook(id)) throw LibraryError("Book ID " + std::to_string(id) + " does not exist.");
    const int loans = activeLoansForBook(id);
    if (loans > 0)
        throw LibraryError("Cannot delete: " + std::to_string(loans) + " copy/copies of this book are currently issued.");
    commit([&] {
        state_.books.erase(std::remove_if(state_.books.begin(), state_.books.end(),
                                          [&](const Book& b) { return b.id() == id; }),
                           state_.books.end());
    });
}

std::vector<Book> Library::searchBooksByTitle(const std::string& text) const {
    std::vector<Book> result;
    for (const Book& b : state_.books) if (containsIgnoreCase(b.title(), text)) result.push_back(b);
    return result;
}
std::vector<Book> Library::searchBooksByAuthor(const std::string& text) const {
    std::vector<Book> result;
    for (const Book& b : state_.books) if (containsIgnoreCase(b.author(), text)) result.push_back(b);
    return result;
}
std::vector<Book> Library::searchBooksByCategory(const std::string& text) const {
    std::vector<Book> result;
    for (const Book& b : state_.books) if (containsIgnoreCase(b.category(), text)) result.push_back(b);
    return result;
}
std::vector<Book> Library::searchBooksByIsbn(const std::string& text) const {
    std::vector<Book> result;
    const std::string wanted = withoutIsbnSeparators(text);
    if (wanted.empty()) return result;
    for (const Book& b : state_.books) if (b.isbn().find(wanted) != std::string::npos) result.push_back(b);
    return result;
}

std::vector<Book> Library::booksSortedByTitle() const {
    std::vector<Book> sorted = state_.books;
    std::sort(sorted.begin(), sorted.end(), [](const Book& a, const Book& b) {
        const std::string ta = toLower(a.title()), tb = toLower(b.title());
        return ta != tb ? ta < tb : a.id() < b.id();
    });
    return sorted;
}

std::vector<Book> Library::booksSortedByYear() const {
    std::vector<Book> sorted = state_.books;
    std::sort(sorted.begin(), sorted.end(), [](const Book& a, const Book& b) {
        if (a.year() != b.year()) return a.year() < b.year();
        const std::string ta = toLower(a.title()), tb = toLower(b.title());
        return ta != tb ? ta < tb : a.id() < b.id();
    });
    return sorted;
}

// ----------------------------------------------------------------------------------------
// Members
// ----------------------------------------------------------------------------------------

int Library::addMember(const MemberData& data, const std::string& registrationDate) {
    asLibraryError([&] { Member::validate(data); return 0; });
    if (memberContactInUse(data, 0)) throw LibraryError("A member with this email address already exists.");
    int id = 0;
    commit([&] {
        id = state_.counters.nextMemberId++;
        state_.members.push_back(asLibraryError([&] { return Member(id, data, registrationDate); }));
    });
    return id;
}

void Library::updateMember(int id, const MemberData& data) {
    if (!findMember(id)) throw LibraryError("Member ID " + std::to_string(id) + " does not exist.");
    asLibraryError([&] { Member::validate(data); return 0; });
    if (memberContactInUse(data, id)) throw LibraryError("Another member already uses this email address.");
    commit([&] { asLibraryError([&] { findMemberMutable(id)->update(data); return 0; }); });
}

void Library::deleteMember(int id) {
    if (!findMember(id)) throw LibraryError("Member ID " + std::to_string(id) + " does not exist.");
    const int loans = activeLoansForMember(id);
    if (loans > 0)
        throw LibraryError("Cannot delete: this member still has " + std::to_string(loans) + " borrowed book(s).");
    commit([&] {
        state_.members.erase(std::remove_if(state_.members.begin(), state_.members.end(),
                                            [&](const Member& m) { return m.id() == id; }),
                             state_.members.end());
    });
}

std::vector<Member> Library::searchMembersByName(const std::string& text) const {
    std::vector<Member> result;
    for (const Member& m : state_.members) if (containsIgnoreCase(m.name(), text)) result.push_back(m);
    return result;
}

// ----------------------------------------------------------------------------------------
// Transactions
// ----------------------------------------------------------------------------------------

Transaction Library::issueBook(int bookId, int memberId, const std::string& issueDate) {
    const Book* book = findBook(bookId);
    if (!book) throw LibraryError("Book ID " + std::to_string(bookId) + " does not exist.");
    if (!findMember(memberId)) throw LibraryError("Member ID " + std::to_string(memberId) + " is not registered.");
    if (!DateUtils::isValidDate(issueDate)) throw LibraryError("Invalid issue date: " + issueDate);
    if (!book->isAvailable()) throw LibraryError("No copies of \"" + book->title() + "\" are currently available.");
    for (const Transaction& t : state_.transactions) {
        if (t.isActive() && t.bookId() == bookId && t.memberId() == memberId)
            throw LibraryError("This member already has this book issued (transaction " + std::to_string(t.id()) + ").");
    }
    Transaction issued;
    commit([&] {
        const int id = state_.counters.nextTransactionId++;
        issued = Transaction(id, bookId, memberId, issueDate,
                             DateUtils::addDays(issueDate, state_.settings.loanPeriodDays));
        findBookMutable(bookId)->checkOut();
        state_.transactions.push_back(issued);
    });
    return issued;
}

long Library::overdueDays(const Transaction& tx, const std::string& asOf) const {
    const std::string& reference = tx.isActive() ? asOf : tx.returnDate();
    return std::max(0L, DateUtils::daysBetween(tx.dueDate(), reference));
}

long long Library::accruedFineCents(const Transaction& tx, const std::string& asOf) const {
    if (!tx.isActive()) return tx.fineCents();
    return overdueDays(tx, asOf) * state_.settings.finePerDayCents;
}

Transaction Library::returnBook(int transactionId, const std::string& returnDate) {
    const Transaction* existing = findTransaction(transactionId);
    if (!existing) throw LibraryError("Transaction " + std::to_string(transactionId) + " does not exist.");
    if (!existing->isActive())
        throw LibraryError("Transaction " + std::to_string(transactionId) + " was already returned on " +
                           existing->returnDate() + ".");
    if (!DateUtils::isValidDate(returnDate)) throw LibraryError("Invalid return date: " + returnDate);
    if (DateUtils::daysBetween(existing->issueDate(), returnDate) < 0)
        throw LibraryError("Return date cannot be earlier than the issue date (" + existing->issueDate() + ").");

    const long late = std::max(0L, DateUtils::daysBetween(existing->dueDate(), returnDate));
    const long long fine = late * state_.settings.finePerDayCents;
    Transaction result;
    commit([&] {
        Transaction* tx = findTransactionMutable(transactionId);
        tx->markReturned(returnDate, fine);
        if (Book* book = findBookMutable(tx->bookId())) book->checkIn();
        result = *tx;
    });
    return result;
}

std::vector<Transaction> Library::activeTransactions() const {
    std::vector<Transaction> result;
    for (const Transaction& t : state_.transactions) if (t.isActive()) result.push_back(t);
    return result;
}

std::vector<Transaction> Library::overdueTransactions(const std::string& asOf) const {
    std::vector<Transaction> result;
    for (const Transaction& t : state_.transactions)
        if (t.isActive() && overdueDays(t, asOf) > 0) result.push_back(t);
    return result;
}

// ----------------------------------------------------------------------------------------
// Settings and sample data
// ----------------------------------------------------------------------------------------

void Library::setLoanPeriodDays(int days) {
    if (days < 1 || days > 365) throw LibraryError("Loan period must be between 1 and 365 days.");
    commit([&] { state_.settings.loanPeriodDays = days; });
}

void Library::setFinePerDayCents(long long cents) {
    if (cents < 0 || cents > 100000) throw LibraryError("Fine per day must be between 0.00 and 1000.00.");
    commit([&] { state_.settings.finePerDayCents = cents; });
}

void Library::importSampleData(const std::string& booksCsv, const std::string& membersCsv,
                               std::size_t& booksImported, std::size_t& membersImported) {
    if (!state_.books.empty() || !state_.members.empty() || !state_.transactions.empty())
        throw LibraryError("Sample data can only be imported into an empty library.");
    if (!FileManager::fileExists(booksCsv) || !FileManager::fileExists(membersCsv))
        throw LibraryError("Sample files not found (" + booksCsv + ", " + membersCsv +
                           "). Start the program from the project folder.");
    std::vector<std::string> warnings;
    std::vector<Book> books = FileManager::loadBooks(booksCsv, warnings);
    std::vector<Member> members = FileManager::loadMembers(membersCsv, warnings);
    if (!warnings.empty()) throw LibraryError("Sample files contain invalid records: " + warnings.front());
    // Sample books start with every copy on the shelf.
    for (Book& b : books) b.setAvailableCopies(b.totalCopies());
    commit([&] {
        installRecords(std::move(books), std::move(members), {}, warnings);
        booksImported = state_.books.size();
        membersImported = state_.members.size();
    });
}
