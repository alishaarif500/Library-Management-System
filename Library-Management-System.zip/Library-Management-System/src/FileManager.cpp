#include "FileManager.h"

#include <filesystem>
#include <fstream>
#include <functional>
#include <sstream>
#include <stdexcept>
#include <system_error>

#include "InputValidator.h"

namespace fs = std::filesystem;

const char* const FileManager::kBooksHeader =
    "id,isbn,title,author,publisher,category,year,total_copies,available_copies";
const char* const FileManager::kMembersHeader = "id,name,phone,email,registered_date";
const char* const FileManager::kTransactionsHeader =
    "id,book_id,member_id,issue_date,due_date,return_date,fine_cents";

namespace {

using RecordHandler = std::function<void(const std::vector<std::string>&)>;

// Reads all lines of a file (strips '\r' and a UTF-8 byte order mark). Missing file -> empty.
std::vector<std::string> readLines(const std::string& path) {
    std::vector<std::string> lines;
    std::ifstream file(path, std::ios::binary);
    if (!file) return lines;
    std::string line;
    while (std::getline(file, line)) {
        if (!line.empty() && line.back() == '\r') line.pop_back();
        lines.push_back(line);
    }
    if (!lines.empty() && lines[0].compare(0, 3, "\xEF\xBB\xBF") == 0) lines[0].erase(0, 3);
    return lines;
}

int toInt(const std::string& text, const char* what) {
    long long value = 0;
    if (!InputValidator::tryParseInt(text, value) || value < -2000000000LL || value > 2000000000LL)
        throw std::invalid_argument(std::string("invalid number for ") + what + ": '" + text + "'");
    return static_cast<int>(value);
}

// Shared CSV loading loop: skips the header, blank lines and bad records (with warnings).
void processCsv(const std::string& path, const std::string& header, std::size_t fieldCount,
                const std::string& label, std::vector<std::string>& warnings,
                const RecordHandler& handler) {
    const std::vector<std::string> lines = readLines(path);
    int skipped = 0;
    for (std::size_t i = 0; i < lines.size(); ++i) {
        const std::string& line = lines[i];
        if (InputValidator::trim(line).empty()) continue;
        if (i == 0 && line == header) continue;
        std::vector<std::string> fields;
        std::string problem;
        if (!FileManager::splitCsvLine(line, fields)) {
            problem = "malformed CSV line";
        } else if (fields.size() != fieldCount) {
            problem = "expected " + std::to_string(fieldCount) + " fields but found " +
                      std::to_string(fields.size());
        } else {
            try {
                handler(fields);
            } catch (const std::exception& e) {
                problem = e.what();
            }
        }
        if (!problem.empty()) {
            ++skipped;
            warnings.push_back(label + " line " + std::to_string(i + 1) + " skipped: " + problem);
        }
    }
    if (skipped > 0) {
        FileManager::backupFile(path);
        warnings.push_back(label + ": " + std::to_string(skipped) +
                           " invalid line(s) skipped; original file copied to " + path + ".corrupt.bak");
    }
}

}  // namespace

std::string FileManager::escapeField(const std::string& field) {
    std::string clean = field;
    for (char& c : clean) {
        if (c == '\n' || c == '\r') c = ' ';  // a record must stay on one line
    }
    if (clean.find_first_of(",\"") == std::string::npos) return clean;
    std::string quoted = "\"";
    for (char c : clean) {
        if (c == '"') quoted += '"';
        quoted += c;
    }
    return quoted + "\"";
}

bool FileManager::splitCsvLine(const std::string& line, std::vector<std::string>& fields) {
    fields.clear();
    std::string current;
    bool inQuotes = false;
    bool justClosedQuote = false;
    for (std::size_t i = 0; i < line.size(); ++i) {
        const char c = line[i];
        if (inQuotes) {
            if (c == '"') {
                if (i + 1 < line.size() && line[i + 1] == '"') { current += '"'; ++i; }
                else { inQuotes = false; justClosedQuote = true; }
            } else {
                current += c;
            }
        } else if (c == ',') {
            fields.push_back(current);
            current.clear();
            justClosedQuote = false;
        } else if (c == '"') {
            if (!current.empty() || justClosedQuote) return false;  // quote in the middle of a field
            inQuotes = true;
        } else {
            if (justClosedQuote) return false;                      // text after a closing quote
            current += c;
        }
    }
    if (inQuotes) return false;
    fields.push_back(current);
    return true;
}

void FileManager::ensureDirectory(const std::string& path) {
    std::error_code ec;
    fs::create_directories(path, ec);
    if (ec || !fs::is_directory(path, ec)) {
        throw std::runtime_error("Cannot create data directory '" + path + "'.");
    }
}

bool FileManager::fileExists(const std::string& path) {
    std::error_code ec;
    return fs::is_regular_file(path, ec);
}

void FileManager::writeFileAtomic(const std::string& path, const std::string& content) {
    const std::string temp = path + ".tmp";
    {
        std::ofstream file(temp, std::ios::binary | std::ios::trunc);
        if (!file) throw std::runtime_error("Cannot write file '" + temp + "'.");
        file << content;
        file.flush();
        if (!file) throw std::runtime_error("Error while writing '" + temp + "'.");
    }  // file closed here (RAII)
    std::error_code ec;
    fs::rename(temp, path, ec);
    if (ec) {  // some platforms refuse to overwrite: remove the old file and retry once
        std::error_code ignored;
        fs::remove(path, ignored);
        fs::rename(temp, path, ec);
        if (ec) {
            fs::remove(temp, ignored);
            throw std::runtime_error("Cannot replace file '" + path + "': " + ec.message());
        }
    }
}

void FileManager::backupFile(const std::string& path) {
    std::error_code ec;
    if (!fs::is_regular_file(path, ec)) return;
    fs::copy_file(path, path + ".corrupt.bak", fs::copy_options::overwrite_existing, ec);
    // A failed backup must not stop the program from starting; ignore ec.
}

void FileManager::saveBooks(const std::string& path, const std::vector<Book>& books) {
    std::ostringstream out;
    out << kBooksHeader << "\n";
    for (const Book& b : books) {
        out << b.id() << ',' << escapeField(b.isbn()) << ',' << escapeField(b.title()) << ','
            << escapeField(b.author()) << ',' << escapeField(b.publisher()) << ','
            << escapeField(b.category()) << ',' << b.year() << ',' << b.totalCopies() << ','
            << b.availableCopies() << "\n";
    }
    writeFileAtomic(path, out.str());
}

void FileManager::saveMembers(const std::string& path, const std::vector<Member>& members) {
    std::ostringstream out;
    out << kMembersHeader << "\n";
    for (const Member& m : members) {
        out << m.id() << ',' << escapeField(m.name()) << ',' << escapeField(m.phone()) << ','
            << escapeField(m.email()) << ',' << m.registrationDate() << "\n";
    }
    writeFileAtomic(path, out.str());
}

void FileManager::saveTransactions(const std::string& path, const std::vector<Transaction>& txs) {
    std::ostringstream out;
    out << kTransactionsHeader << "\n";
    for (const Transaction& t : txs) {
        out << t.id() << ',' << t.bookId() << ',' << t.memberId() << ',' << t.issueDate() << ','
            << t.dueDate() << ',' << t.returnDate() << ',' << t.fineCents() << "\n";
    }
    writeFileAtomic(path, out.str());
}

void FileManager::saveSettings(const std::string& path, const Settings& s, const IdCounters& c) {
    std::ostringstream out;
    out << "# Library Management System settings (fine_per_day_cents: 50 means 0.50)\n"
        << "loan_period_days=" << s.loanPeriodDays << "\n"
        << "fine_per_day_cents=" << s.finePerDayCents << "\n"
        << "next_book_id=" << c.nextBookId << "\n"
        << "next_member_id=" << c.nextMemberId << "\n"
        << "next_transaction_id=" << c.nextTransactionId << "\n";
    writeFileAtomic(path, out.str());
}

std::vector<Book> FileManager::loadBooks(const std::string& path, std::vector<std::string>& warnings) {
    std::vector<Book> books;
    processCsv(path, kBooksHeader, 9, "books", warnings, [&](const std::vector<std::string>& f) {
        BookData d;
        d.isbn = f[1]; d.title = f[2]; d.author = f[3]; d.publisher = f[4]; d.category = f[5];
        d.year = toInt(f[6], "year");
        d.totalCopies = toInt(f[7], "total copies");
        books.emplace_back(toInt(f[0], "id"), d, toInt(f[8], "available copies"));
    });
    return books;
}

std::vector<Member> FileManager::loadMembers(const std::string& path, std::vector<std::string>& warnings) {
    std::vector<Member> members;
    processCsv(path, kMembersHeader, 5, "members", warnings, [&](const std::vector<std::string>& f) {
        MemberData d;
        d.name = f[1]; d.phone = f[2]; d.email = f[3];
        members.emplace_back(toInt(f[0], "id"), d, f[4]);
    });
    return members;
}

std::vector<Transaction> FileManager::loadTransactions(const std::string& path,
                                                       std::vector<std::string>& warnings) {
    std::vector<Transaction> txs;
    processCsv(path, kTransactionsHeader, 7, "transactions", warnings, [&](const std::vector<std::string>& f) {
        long long fine = 0;
        if (!InputValidator::tryParseInt(f[6], fine)) throw std::invalid_argument("invalid fine value");
        txs.emplace_back(toInt(f[0], "id"), toInt(f[1], "book id"), toInt(f[2], "member id"),
                         f[3], f[4], f[5], fine);
    });
    return txs;
}

void FileManager::loadSettings(const std::string& path, Settings& settings, IdCounters& counters,
                               std::vector<std::string>& warnings) {
    for (const std::string& raw : readLines(path)) {
        const std::string line = InputValidator::trim(raw);
        if (line.empty() || line[0] == '#') continue;
        const std::size_t eq = line.find('=');
        long long value = 0;
        if (eq == std::string::npos || !InputValidator::tryParseInt(line.substr(eq + 1), value)) {
            warnings.push_back("settings: ignored invalid line '" + line + "'");
            continue;
        }
        const std::string key = InputValidator::trim(line.substr(0, eq));
        if (key == "loan_period_days" && value >= 1 && value <= 365) settings.loanPeriodDays = static_cast<int>(value);
        else if (key == "fine_per_day_cents" && value >= 0 && value <= 100000) settings.finePerDayCents = value;
        else if (key == "next_book_id" && value >= 1 && value <= 2000000000) counters.nextBookId = static_cast<int>(value);
        else if (key == "next_member_id" && value >= 1 && value <= 2000000000) counters.nextMemberId = static_cast<int>(value);
        else if (key == "next_transaction_id" && value >= 1 && value <= 2000000000) counters.nextTransactionId = static_cast<int>(value);
        else warnings.push_back("settings: ignored unknown or out-of-range entry '" + line + "'");
    }
}
