#include "DateUtils.h"

#include <cstdio>
#include <ctime>
#include <stdexcept>

namespace {

bool isLeapYear(int year) {
    return (year % 4 == 0 && year % 100 != 0) || year % 400 == 0;
}

int daysInMonth(int year, int month) {
    static const int days[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
    return (month == 2 && isLeapYear(year)) ? 29 : days[month - 1];
}

// Splits "YYYY-MM-DD" and checks it is a real calendar date.
bool parseDate(const std::string& text, int& year, int& month, int& day) {
    if (text.size() != 10 || text[4] != '-' || text[7] != '-') return false;
    for (std::size_t i = 0; i < text.size(); ++i) {
        if (i == 4 || i == 7) continue;
        if (text[i] < '0' || text[i] > '9') return false;
    }
    year = std::stoi(text.substr(0, 4));
    month = std::stoi(text.substr(5, 2));
    day = std::stoi(text.substr(8, 2));
    if (year < 1900 || year > 2200) return false;
    if (month < 1 || month > 12) return false;
    return day >= 1 && day <= daysInMonth(year, month);
}

// Civil date <-> day count conversion (public-domain algorithm by Howard Hinnant).
long daysFromCivil(long y, long m, long d) {
    y -= m <= 2;
    const long era = (y >= 0 ? y : y - 399) / 400;
    const long yoe = y - era * 400;
    const long doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    const long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + doe - 719468;
}

void civilFromDays(long z, int& year, int& month, int& day) {
    z += 719468;
    const long era = (z >= 0 ? z : z - 146096) / 146097;
    const long doe = z - era * 146097;
    const long yoe = (doe - doe / 1460 + doe / 36524 - doe / 146096) / 365;
    const long doy = doe - (365 * yoe + yoe / 4 - yoe / 100);
    const long mp = (5 * doy + 2) / 153;
    const long d = doy - (153 * mp + 2) / 5 + 1;
    const long m = mp < 10 ? mp + 3 : mp - 9;
    year = static_cast<int>(yoe + era * 400 + (m <= 2 ? 1 : 0));
    month = static_cast<int>(m);
    day = static_cast<int>(d);
}

}  // namespace

namespace DateUtils {

bool isValidDate(const std::string& date) {
    int y = 0, m = 0, d = 0;
    return parseDate(date, y, m, d);
}

std::string today() {
    const std::time_t now = std::time(nullptr);
    std::tm local{};
#ifdef _WIN32
    localtime_s(&local, &now);
#else
    localtime_r(&now, &local);
#endif
    char buffer[64];
    std::snprintf(buffer, sizeof(buffer), "%04d-%02d-%02d", local.tm_year + 1900,
                  local.tm_mon + 1, local.tm_mday);
    return buffer;
}

long toDayNumber(const std::string& date) {
    int y = 0, m = 0, d = 0;
    if (!parseDate(date, y, m, d)) {
        throw std::invalid_argument("Invalid date (expected YYYY-MM-DD): " + date);
    }
    return daysFromCivil(y, m, d);
}

std::string addDays(const std::string& date, int days) {
    int y = 0, m = 0, d = 0;
    civilFromDays(toDayNumber(date) + days, y, m, d);
    char buffer[64];
    std::snprintf(buffer, sizeof(buffer), "%04d-%02d-%02d", y, m, d);
    return buffer;
}

long daysBetween(const std::string& from, const std::string& to) {
    return toDayNumber(to) - toDayNumber(from);
}

}  // namespace DateUtils
