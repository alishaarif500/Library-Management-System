// Library Management System - program entry point.
// Usage: LibraryManagementSystem [data_directory]
// The data directory defaults to "data/db" (relative to the folder the program is started from).

#include <iostream>
#include <string>

#include "ConsoleUI.h"
#include "InputValidator.h"
#include "Library.h"

int main(int argc, char* argv[]) {
    std::string dataDirectory = "data/db";
    if (argc > 1) {
        const std::string arg = argv[1];
        if (arg == "--help" || arg == "-h") {
            std::cout << "Usage: " << argv[0] << " [data_directory]\n"
                      << "  data_directory  where the .csv/.ini data files are kept (default: data/db)\n";
            return 0;
        }
        dataDirectory = arg;
    }

    try {
        Library library(dataDirectory);
        const std::vector<std::string> warnings = library.load();
        for (const std::string& w : warnings) std::cout << "[Warning] " << w << "\n";

        ConsoleUI ui(library);
        try {
            ui.run();
        } catch (const InputClosedError&) {
            // Input ended (Ctrl+Z / closed pipe). All changes were already saved after each operation.
            std::cout << "\nInput closed. All data has been saved. Goodbye!\n";
        }
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "Fatal error: " << e.what() << "\n";
        return 1;
    }
}
