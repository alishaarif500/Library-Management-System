#include "Member.h"

#include <stdexcept>

#include "DateUtils.h"
#include "InputValidator.h"

void Member::validate(const MemberData& d) {
    if (!InputValidator::isValidRequiredText(d.name))
        throw std::invalid_argument("Name must be 1-100 printable characters.");
    if (!InputValidator::isValidPhone(d.phone))
        throw std::invalid_argument("Contact number must have 7-15 digits (spaces, -, (), leading + allowed).");
    if (!InputValidator::isValidEmail(d.email))
        throw std::invalid_argument("Email address is not valid (example: name@example.com).");
}

Member::Member(int id, const MemberData& data, const std::string& registrationDate) {
    if (id <= 0) throw std::invalid_argument("Member ID must be positive.");
    validate(data);
    if (!DateUtils::isValidDate(registrationDate))
        throw std::invalid_argument("Registration date is invalid: " + registrationDate);
    id_ = id;
    name_ = InputValidator::trim(data.name);
    phone_ = InputValidator::trim(data.phone);
    email_ = InputValidator::trim(data.email);
    registrationDate_ = registrationDate;
}

void Member::update(const MemberData& data) {
    validate(data);
    name_ = InputValidator::trim(data.name);
    phone_ = InputValidator::trim(data.phone);
    email_ = InputValidator::trim(data.email);
}
