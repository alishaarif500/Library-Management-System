#include "Transaction.h"

#include <stdexcept>

#include "DateUtils.h"

Transaction::Transaction(int id, int bookId, int memberId, const std::string& issueDate,
                         const std::string& dueDate, const std::string& returnDate,
                         long long fineCents) {
    if (id <= 0 || bookId <= 0 || memberId <= 0) throw std::invalid_argument("IDs must be positive.");
    if (!DateUtils::isValidDate(issueDate)) throw std::invalid_argument("Invalid issue date: " + issueDate);
    if (!DateUtils::isValidDate(dueDate)) throw std::invalid_argument("Invalid due date: " + dueDate);
    if (DateUtils::daysBetween(issueDate, dueDate) < 0)
        throw std::invalid_argument("Due date is earlier than the issue date.");
    if (!returnDate.empty()) {
        if (!DateUtils::isValidDate(returnDate)) throw std::invalid_argument("Invalid return date: " + returnDate);
        if (DateUtils::daysBetween(issueDate, returnDate) < 0)
            throw std::invalid_argument("Return date is earlier than the issue date.");
    }
    if (fineCents < 0) throw std::invalid_argument("Fine cannot be negative.");
    if (returnDate.empty() && fineCents != 0)
        throw std::invalid_argument("An active transaction cannot have a recorded fine.");
    id_ = id;
    bookId_ = bookId;
    memberId_ = memberId;
    issueDate_ = issueDate;
    dueDate_ = dueDate;
    returnDate_ = returnDate;
    fineCents_ = fineCents;
}

void Transaction::markReturned(const std::string& returnDate, long long fineCents) {
    if (!isActive()) throw std::logic_error("Transaction was already returned.");
    if (!DateUtils::isValidDate(returnDate)) throw std::invalid_argument("Invalid return date: " + returnDate);
    if (DateUtils::daysBetween(issueDate_, returnDate) < 0)
        throw std::invalid_argument("Return date cannot be earlier than the issue date.");
    if (fineCents < 0) throw std::invalid_argument("Fine cannot be negative.");
    returnDate_ = returnDate;
    fineCents_ = fineCents;
}
