#include "InputValidator.h"

#include <algorithm>
#include <cctype>

namespace InputValidator {

std::string trim(const std::string& text) {
    std::size_t start = 0;
    std::size_t end = text.size();
    while (start < end && std::isspace(static_cast<unsigned char>(text[start]))) ++start;
    while (end > start && std::isspace(static_cast<unsigned char>(text[end - 1]))) --end;
    return text.substr(start, end - start);
}

std::string toLower(const std::string& text) {
    std::string result = text;
    std::transform(result.begin(), result.end(), result.begin(),
                   [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    return result;
}

bool isSafeText(const std::string& text) {
    return std::all_of(text.begin(), text.end(), [](unsigned char c) { return c >= 0x20 && c != 0x7F; });
}

bool isValidRequiredText(const std::string& text, std::size_t maxLength) {
    const std::string trimmed = trim(text);
    return !trimmed.empty() && trimmed.size() <= maxLength && isSafeText(trimmed);
}

bool tryParseInt(const std::string& text, long long& value) {
    const std::string s = trim(text);
    if (s.empty()) return false;
    std::size_t i = 0;
    if (s[0] == '-' || s[0] == '+') i = 1;
    if (i >= s.size() || s.size() - i > 18) return false;  // also protects against overflow
    for (std::size_t k = i; k < s.size(); ++k) {
        if (!std::isdigit(static_cast<unsigned char>(s[k]))) return false;
    }
    value = std::stoll(s);
    return true;
}

bool tryParseMoney(const std::string& text, long long& cents) {
    const std::string s = trim(text);
    if (s.empty() || s.size() > 12) return false;
    const std::size_t dot = s.find('.');
    const std::string whole = s.substr(0, dot);
    const std::string fraction = (dot == std::string::npos) ? "" : s.substr(dot + 1);
    if (whole.empty() && fraction.empty()) return false;
    if (fraction.size() > 2) return false;
    for (char c : whole) if (!std::isdigit(static_cast<unsigned char>(c))) return false;
    for (char c : fraction) if (!std::isdigit(static_cast<unsigned char>(c))) return false;
    long long result = whole.empty() ? 0 : std::stoll(whole) * 100;
    if (fraction.size() == 1) result += (fraction[0] - '0') * 10;
    if (fraction.size() == 2) result += (fraction[0] - '0') * 10 + (fraction[1] - '0');
    cents = result;
    return true;
}

bool isValidEmail(const std::string& text) {
    const std::string s = trim(text);
    if (s.empty() || s.size() > kMaxTextLength) return false;
    for (unsigned char c : s) if (c <= 0x20 || c == 0x7F) return false;
    const std::size_t at = s.find('@');
    if (at == std::string::npos || at == 0 || s.find('@', at + 1) != std::string::npos) return false;
    const std::string domain = s.substr(at + 1);
    const std::size_t dot = domain.rfind('.');
    return dot != std::string::npos && dot > 0 && dot + 1 < domain.size() &&
           domain.front() != '.' && domain.back() != '.';
}

bool isValidPhone(const std::string& text) {
    const std::string s = trim(text);
    if (s.empty() || s.size() > 30) return false;
    int digits = 0;
    for (std::size_t i = 0; i < s.size(); ++i) {
        const char c = s[i];
        if (std::isdigit(static_cast<unsigned char>(c))) ++digits;
        else if (c == '+' && i == 0) continue;
        else if (c == ' ' || c == '-' || c == '(' || c == ')') continue;
        else return false;
    }
    return digits >= 7 && digits <= 15;
}

std::string normalizeIsbn(const std::string& text) {
    std::string result;
    for (char c : trim(text)) {
        if (c == '-' || c == ' ') continue;
        result += static_cast<char>(std::toupper(static_cast<unsigned char>(c)));
    }
    if (result.size() == 13) {
        if (!std::all_of(result.begin(), result.end(), [](unsigned char c) { return std::isdigit(c) != 0; })) return "";
        return result;
    }
    if (result.size() == 10) {
        for (std::size_t i = 0; i < 9; ++i) if (!std::isdigit(static_cast<unsigned char>(result[i]))) return "";
        const char last = result[9];
        if (!std::isdigit(static_cast<unsigned char>(last)) && last != 'X') return "";
        return result;
    }
    return "";
}

std::string readLine(const std::string& prompt, std::istream& in, std::ostream& out) {
    out << prompt << std::flush;
    std::string line;
    if (!std::getline(in, line)) throw InputClosedError();
    if (!line.empty() && line.back() == '\r') line.pop_back();
    return trim(line);
}

std::string readValidated(const std::string& prompt, const Checker& checker, std::istream& in,
                          std::ostream& out) {
    while (true) {
        const std::string value = readLine(prompt, in, out);
        std::string error;
        if (checker(value, error)) return value;
        out << "  [!] " << error << "\n";
    }
}

std::string readRequiredText(const std::string& prompt, std::istream& in, std::ostream& out) {
    return readValidated(prompt,
        [](const std::string& v, std::string& err) {
            if (isValidRequiredText(v)) return true;
            err = "Please enter 1-100 printable characters (cannot be empty).";
            return false;
        }, in, out);
}

int readInt(const std::string& prompt, int minValue, int maxValue, std::istream& in, std::ostream& out) {
    while (true) {
        const std::string line = readLine(prompt, in, out);
        long long value = 0;
        if (tryParseInt(line, value) && value >= minValue && value <= maxValue) {
            return static_cast<int>(value);
        }
        out << "  [!] Invalid input. Enter a whole number from " << minValue << " to " << maxValue << ".\n";
    }
}

int readOptionalInt(const std::string& prompt, int current, int minValue, int maxValue,
                    std::istream& in, std::ostream& out) {
    while (true) {
        const std::string line = readLine(prompt, in, out);
        if (line.empty()) return current;
        long long value = 0;
        if (tryParseInt(line, value) && value >= minValue && value <= maxValue) {
            return static_cast<int>(value);
        }
        out << "  [!] Invalid input. Enter a whole number from " << minValue << " to " << maxValue
            << " (or press Enter to keep the current value).\n";
    }
}

std::string readOptionalText(const std::string& prompt, const std::string& current,
                             const Checker& checker, std::istream& in, std::ostream& out) {
    while (true) {
        const std::string line = readLine(prompt, in, out);
        if (line.empty()) return current;
        std::string error;
        if (checker(line, error)) return line;
        out << "  [!] " << error << "\n";
    }
}

bool confirm(const std::string& prompt, std::istream& in, std::ostream& out) {
    while (true) {
        const std::string answer = toLower(readLine(prompt + " (y/n): ", in, out));
        if (answer == "y" || answer == "yes") return true;
        if (answer == "n" || answer == "no") return false;
        out << "  [!] Please answer y or n.\n";
    }
}

}  // namespace InputValidator
