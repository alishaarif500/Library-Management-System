#include "ReportManager.h"

#include <algorithm>
#include <iomanip>
#include <unordered_map>

Statistics ReportManager::compute(const std::string& asOf) const {
    Statistics s;
    s.totalBookTitles = library_.books().size();
    for (const Book& b : library_.books()) {
        s.totalCopies += b.totalCopies();
        s.availableCopies += b.availableCopies();
    }
    s.issuedCopies = s.totalCopies - s.availableCopies;
    s.totalMembers = library_.members().size();
    for (const Transaction& t : library_.transactions()) {
        if (t.isActive()) {
            ++s.activeTransactions;
            if (library_.overdueDays(t, asOf) > 0) {
                ++s.overdueTransactions;
                s.outstandingFinesCents += library_.accruedFineCents(t, asOf);
            }
        } else {
            ++s.returnedTransactions;
            s.collectedFinesCents += t.fineCents();
        }
    }
    return s;
}

std::vector<BorrowCount> ReportManager::mostBorrowed(std::size_t limit) const {
    std::unordered_map<int, int> counts;  // book ID -> number of loans (active + returned)
    for (const Transaction& t : library_.transactions()) ++counts[t.bookId()];

    std::vector<BorrowCount> result;
    for (const auto& entry : counts) {
        BorrowCount c;
        c.bookId = entry.first;
        c.timesBorrowed = entry.second;
        const Book* book = library_.findBook(entry.first);
        c.title = book ? book->title() : "[deleted book]";
        result.push_back(c);
    }
    std::sort(result.begin(), result.end(), [](const BorrowCount& a, const BorrowCount& b) {
        if (a.timesBorrowed != b.timesBorrowed) return a.timesBorrowed > b.timesBorrowed;
        return a.bookId < b.bookId;
    });
    if (result.size() > limit) result.resize(limit);
    return result;
}

void ReportManager::printSummary(std::ostream& out, const std::string& asOf) const {
    const Statistics s = compute(asOf);
    auto row = [&](const std::string& label, const std::string& value) {
        out << "  " << std::left << std::setw(46) << label << value << "\n";
    };
    row("Report date:", asOf);
    row("Total registered books (titles):", std::to_string(s.totalBookTitles));
    row("Total copies in the library:", std::to_string(s.totalCopies));
    row("Total available copies:", std::to_string(s.availableCopies));
    row("Total issued copies:", std::to_string(s.issuedCopies));
    row("Total registered members:", std::to_string(s.totalMembers));
    row("Active borrowing transactions:", std::to_string(s.activeTransactions));
    row("Returned books (completed loans):", std::to_string(s.returnedTransactions));
    row("Overdue books (not yet returned):", std::to_string(s.overdueTransactions));
    row("Outstanding fines (overdue, unreturned):", formatCents(s.outstandingFinesCents));
    row("Fines recorded on returned books:", formatCents(s.collectedFinesCents));
}

void ReportManager::printMostBorrowed(std::ostream& out, std::size_t limit) const {
    const std::vector<BorrowCount> top = mostBorrowed(limit);
    if (top.empty()) {
        out << "  Not enough history yet: no books have been borrowed.\n";
        return;
    }
    out << "  " << std::left << std::setw(6) << "Rank" << std::setw(8) << "BookID" << std::setw(40)
        << "Title" << "Times borrowed\n";
    int rank = 1;
    for (const BorrowCount& c : top) {
        std::string title = c.title.size() > 38 ? c.title.substr(0, 36) + ".." : c.title;
        out << "  " << std::left << std::setw(6) << rank++ << std::setw(8) << c.bookId << std::setw(40)
            << title << c.timesBorrowed << "\n";
    }
}
