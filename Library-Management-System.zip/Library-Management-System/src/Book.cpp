#include "Book.h"

#include <stdexcept>

#include "InputValidator.h"

using InputValidator::isValidRequiredText;
using InputValidator::trim;

void Book::validate(const BookData& d) {
    if (InputValidator::normalizeIsbn(d.isbn).empty())
        throw std::invalid_argument("ISBN must contain 10 or 13 characters (hyphens allowed).");
    if (!isValidRequiredText(d.title)) throw std::invalid_argument("Title must be 1-100 printable characters.");
    if (!isValidRequiredText(d.author)) throw std::invalid_argument("Author must be 1-100 printable characters.");
    if (!isValidRequiredText(d.publisher)) throw std::invalid_argument("Publisher must be 1-100 printable characters.");
    if (!isValidRequiredText(d.category)) throw std::invalid_argument("Category must be 1-100 printable characters.");
    if (d.year < 1000 || d.year > 2100) throw std::invalid_argument("Publication year must be between 1000 and 2100.");
    if (d.totalCopies < 1 || d.totalCopies > 100000)
        throw std::invalid_argument("Total copies must be between 1 and 100000.");
}

Book::Book(int id, const BookData& data, int availableCopies) {
    if (id <= 0) throw std::invalid_argument("Book ID must be positive.");
    validate(data);
    if (availableCopies < 0 || availableCopies > data.totalCopies)
        throw std::invalid_argument("Available copies must be between 0 and total copies.");
    id_ = id;
    isbn_ = InputValidator::normalizeIsbn(data.isbn);
    title_ = trim(data.title);
    author_ = trim(data.author);
    publisher_ = trim(data.publisher);
    category_ = trim(data.category);
    year_ = data.year;
    total_ = data.totalCopies;
    available_ = availableCopies;
}

void Book::update(const BookData& data) {
    validate(data);
    const int issued = issuedCopies();
    if (data.totalCopies < issued)
        throw std::invalid_argument("Total copies cannot be lower than the " + std::to_string(issued) +
                                    " copies currently issued.");
    isbn_ = InputValidator::normalizeIsbn(data.isbn);
    title_ = trim(data.title);
    author_ = trim(data.author);
    publisher_ = trim(data.publisher);
    category_ = trim(data.category);
    year_ = data.year;
    total_ = data.totalCopies;
    available_ = total_ - issued;
}

void Book::checkOut() {
    if (available_ <= 0) throw std::logic_error("No copies available.");
    --available_;
}

void Book::checkIn() {
    if (available_ >= total_) throw std::logic_error("All copies are already in the library.");
    ++available_;
}

void Book::setAvailableCopies(int available) {
    if (available < 0 || available > total_) throw std::invalid_argument("Available copies out of range.");
    available_ = available;
}
