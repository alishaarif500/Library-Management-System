#ifndef CONSOLE_UI_H
#define CONSOLE_UI_H

#include <functional>
#include <iostream>
#include <string>
#include <vector>

#include "Library.h"

// The menu-driven text interface. Input/output streams are injectable so the interface can be
// driven by scripted input in automated tests.
class ConsoleUI {
public:
    ConsoleUI(Library& library, std::istream& in = std::cin, std::ostream& out = std::cout);

    // Runs the main menu until the user chooses Exit. Throws InputClosedError if input ends.
    void run();

private:
    // helpers
    void header(const std::string& title);
    int showMenu(const std::string& title, const std::vector<std::string>& items, const std::string& zeroLabel);
    void pause();
    void runAction(const std::function<void()>& action);
    int askId(const std::string& prompt);  // returns 0 when the user cancels
    void printBooks(const std::vector<Book>& books);
    void printMembers(const std::vector<Member>& members);
    void printTransactions(const std::vector<Transaction>& txs);
    BookData promptBookData(const Book* current);
    MemberData promptMemberData(const Member* current);

    // screens
    void dashboard();
    void bookMenu();
    void memberMenu();
    void issueScreen();
    void returnMenu();
    void searchMenu();
    void reportsMenu();
    void settingsMenu();
    void helpScreen();

    // actions
    void addBook();
    void updateBook();
    void deleteBook();
    void addMember();
    void updateMember();
    void deleteMember();
    void returnBook();
    void importSamples();

    Library& library_;
    std::istream& in_;
    std::ostream& out_;
};

#endif
