#ifndef BOOK_H
#define BOOK_H

#include <string>

// The editable descriptive fields of a book (used for adding and updating).
struct BookData {
    std::string isbn;
    std::string title;
    std::string author;
    std::string publisher;
    std::string category;
    int year = 0;
    int totalCopies = 0;
};

// A book title in the catalogue together with its copy counts.
// Invariants (enforced by the constructor and mutators): 1 <= total, 0 <= available <= total.
class Book {
public:
    Book() = default;
    // Throws std::invalid_argument when any value is invalid.
    Book(int id, const BookData& data, int availableCopies);

    // Validates user-supplied data; throws std::invalid_argument with a readable message.
    static void validate(const BookData& data);

    int id() const { return id_; }
    const std::string& isbn() const { return isbn_; }
    const std::string& title() const { return title_; }
    const std::string& author() const { return author_; }
    const std::string& publisher() const { return publisher_; }
    const std::string& category() const { return category_; }
    int year() const { return year_; }
    int totalCopies() const { return total_; }
    int availableCopies() const { return available_; }
    int issuedCopies() const { return total_ - available_; }
    bool isAvailable() const { return available_ > 0; }

    // Replaces descriptive data and total copies; available copies are recalculated so that
    // the number of issued copies stays the same. Throws if total < issued copies.
    void update(const BookData& data);
    void checkOut();   // one copy leaves the shelf; throws std::logic_error if none available
    void checkIn();    // one copy returns; throws std::logic_error if all copies are already in
    void setAvailableCopies(int available);  // used when repairing loaded data

private:
    int id_ = 0;
    std::string isbn_;
    std::string title_;
    std::string author_;
    std::string publisher_;
    std::string category_;
    int year_ = 0;
    int total_ = 0;
    int available_ = 0;
};

#endif
