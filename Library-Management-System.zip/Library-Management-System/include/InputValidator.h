#ifndef INPUT_VALIDATOR_H
#define INPUT_VALIDATOR_H

#include <cstddef>
#include <functional>
#include <iostream>
#include <stdexcept>
#include <string>

// Thrown when the input stream ends (Ctrl+Z / Ctrl+D / closed pipe) so that the
// program can exit cleanly instead of looping forever.
class InputClosedError : public std::runtime_error {
public:
    InputClosedError() : std::runtime_error("Input stream closed") {}
};

// Pure validators (no I/O) and safe interactive readers.
namespace InputValidator {

constexpr std::size_t kMaxTextLength = 100;

// ---- Pure helpers -----------------------------------------------------------
std::string trim(const std::string& text);
std::string toLower(const std::string& text);
bool isSafeText(const std::string& text);                 // no control characters
bool isValidRequiredText(const std::string& text, std::size_t maxLength = kMaxTextLength);
bool tryParseInt(const std::string& text, long long& value);   // whole string must be a number
bool tryParseMoney(const std::string& text, long long& cents); // "5", "5.5", "5.50" -> hundredths
bool isValidEmail(const std::string& text);
bool isValidPhone(const std::string& text);
// Returns the ISBN without hyphens/spaces (upper-case), or "" if it is not a 10 or 13 character ISBN.
std::string normalizeIsbn(const std::string& text);

// ---- Interactive readers ----------------------------------------------------
// A checker returns true when the text is acceptable, otherwise fills in an error message.
using Checker = std::function<bool(const std::string&, std::string&)>;

std::string readLine(const std::string& prompt, std::istream& in = std::cin,
                     std::ostream& out = std::cout);
std::string readValidated(const std::string& prompt, const Checker& checker,
                          std::istream& in = std::cin, std::ostream& out = std::cout);
std::string readRequiredText(const std::string& prompt, std::istream& in = std::cin,
                             std::ostream& out = std::cout);
int readInt(const std::string& prompt, int minValue, int maxValue, std::istream& in = std::cin,
            std::ostream& out = std::cout);
// Empty input keeps `current`.
int readOptionalInt(const std::string& prompt, int current, int minValue, int maxValue,
                    std::istream& in = std::cin, std::ostream& out = std::cout);
std::string readOptionalText(const std::string& prompt, const std::string& current,
                             const Checker& checker, std::istream& in = std::cin,
                             std::ostream& out = std::cout);
bool confirm(const std::string& prompt, std::istream& in = std::cin, std::ostream& out = std::cout);

}  // namespace InputValidator

#endif
