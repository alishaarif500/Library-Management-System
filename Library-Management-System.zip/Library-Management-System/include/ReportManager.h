#ifndef REPORT_MANAGER_H
#define REPORT_MANAGER_H

#include <ostream>
#include <string>
#include <vector>

#include "Library.h"

// Numbers shown on the dashboard and in the reports. Always computed from the stored records.
struct Statistics {
    std::size_t totalBookTitles = 0;
    long long totalCopies = 0;
    long long availableCopies = 0;
    long long issuedCopies = 0;
    std::size_t totalMembers = 0;
    std::size_t activeTransactions = 0;
    std::size_t returnedTransactions = 0;
    std::size_t overdueTransactions = 0;
    long long outstandingFinesCents = 0;  // fines accrued so far on overdue loans that are still out
    long long collectedFinesCents = 0;    // fines recorded when overdue books were returned
};

struct BorrowCount {
    int bookId = 0;
    std::string title;      // "[deleted book]" if the book no longer exists
    int timesBorrowed = 0;
};

class ReportManager {
public:
    explicit ReportManager(const Library& library) : library_(library) {}

    Statistics compute(const std::string& asOf = DateUtils::today()) const;
    // Books ordered by number of loans (most first). Books never borrowed are not listed.
    std::vector<BorrowCount> mostBorrowed(std::size_t limit = 5) const;

    void printSummary(std::ostream& out, const std::string& asOf = DateUtils::today()) const;
    void printMostBorrowed(std::ostream& out, std::size_t limit = 5) const;

private:
    const Library& library_;
};

#endif
