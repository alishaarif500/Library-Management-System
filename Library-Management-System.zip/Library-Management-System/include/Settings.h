#ifndef SETTINGS_H
#define SETTINGS_H

#include <string>

// User-configurable application settings (stored in data/db/settings.ini).
struct Settings {
    int loanPeriodDays = 14;          // days between issue date and due date
    long long finePerDayCents = 50;   // overdue fine per day, in hundredths (50 = 0.50)
};

// Next unique ID to hand out. Persisted so IDs are never reused after deletions.
struct IdCounters {
    int nextBookId = 1;
    int nextMemberId = 1;
    int nextTransactionId = 1;
};

// Formats an amount stored in hundredths as "12.50".
inline std::string formatCents(long long cents) {
    const bool negative = cents < 0;
    const long long absolute = negative ? -cents : cents;
    const long long fraction = absolute % 100;
    std::string text = std::to_string(absolute / 100) + "." +
                       (fraction < 10 ? "0" : "") + std::to_string(fraction);
    return negative ? "-" + text : text;
}

#endif
