#ifndef LIBRARY_H
#define LIBRARY_H

#include <functional>
#include <stdexcept>
#include <string>
#include <unordered_map>
#include <vector>

#include "Book.h"
#include "DateUtils.h"
#include "Member.h"
#include "Settings.h"
#include "Transaction.h"

// Thrown for every rule violation (unknown ID, no copies left, duplicate record, ...).
// The message is written for the end user.
class LibraryError : public std::runtime_error {
public:
    explicit LibraryError(const std::string& message) : std::runtime_error(message) {}
};

// The business-logic core. Owns all records, enforces every rule, and saves to disk after
// every successful change. If saving fails the change is rolled back, so memory and disk
// never disagree.
//
// Data structures:
//  * std::vector            - ordered storage of records (cheap to iterate, sort and print)
//  * std::unordered_map     - ID -> position index for O(1) lookups
class Library {
public:
    // `dataDirectory` is where books.csv, members.csv, transactions.csv and settings.ini live.
    // Nothing is read or written until load() is called.
    explicit Library(std::string dataDirectory);

    // Creates the directory/files if needed and loads all records. Returns warnings (skipped
    // corrupt lines, repaired inconsistencies). Throws LibraryError if the directory is unusable.
    std::vector<std::string> load();
    void save() const;  // throws LibraryError
    const std::string& dataDirectory() const { return dataDirectory_; }

    // ---- Books ----
    int addBook(const BookData& data);                        // returns the new ID
    void updateBook(int id, const BookData& data);
    void deleteBook(int id);                                  // refused while copies are issued
    const Book* findBook(int id) const;
    const std::vector<Book>& books() const { return state_.books; }
    std::vector<Book> searchBooksByTitle(const std::string& text) const;
    std::vector<Book> searchBooksByAuthor(const std::string& text) const;
    std::vector<Book> searchBooksByIsbn(const std::string& text) const;
    std::vector<Book> searchBooksByCategory(const std::string& text) const;
    std::vector<Book> booksSortedByTitle() const;
    std::vector<Book> booksSortedByYear() const;

    // ---- Members ----
    int addMember(const MemberData& data, const std::string& registrationDate = DateUtils::today());
    void updateMember(int id, const MemberData& data);
    void deleteMember(int id);                                // refused while the member has loans
    const Member* findMember(int id) const;
    const std::vector<Member>& members() const { return state_.members; }
    std::vector<Member> searchMembersByName(const std::string& text) const;

    // ---- Transactions ----
    Transaction issueBook(int bookId, int memberId, const std::string& issueDate = DateUtils::today());
    Transaction returnBook(int transactionId, const std::string& returnDate = DateUtils::today());
    const Transaction* findTransaction(int id) const;
    const std::vector<Transaction>& transactions() const { return state_.transactions; }
    std::vector<Transaction> activeTransactions() const;
    std::vector<Transaction> overdueTransactions(const std::string& asOf = DateUtils::today()) const;
    int activeLoansForBook(int bookId) const;
    int activeLoansForMember(int memberId) const;
    // Days past the due date (0 if on time). For an active loan `asOf` is the reference date.
    long overdueDays(const Transaction& tx, const std::string& asOf = DateUtils::today()) const;
    // Fine that has built up so far for an active loan (returned loans use their stored fine).
    long long accruedFineCents(const Transaction& tx, const std::string& asOf = DateUtils::today()) const;

    // ---- Settings ----
    const Settings& settings() const { return state_.settings; }
    void setLoanPeriodDays(int days);                         // 1..365
    void setFinePerDayCents(long long cents);                 // 0..100000

    // Loads sample CSV files; only allowed when the library has no books, members or transactions.
    // Returns the number of (books, members) imported via the out parameters.
    void importSampleData(const std::string& booksCsv, const std::string& membersCsv,
                          std::size_t& booksImported, std::size_t& membersImported);

private:
    struct State {
        std::vector<Book> books;
        std::vector<Member> members;
        std::vector<Transaction> transactions;
        Settings settings;
        IdCounters counters;
    };

    std::string path(const char* fileName) const;
    void rebuildIndexes();
    // Installs loaded records after cross-checking them. Returns true if any record was dropped.
    bool installRecords(std::vector<Book> books, std::vector<Member> members,
                        std::vector<Transaction> txs, std::vector<std::string>& warnings);
    void commit(const std::function<void()>& change);        // apply + save, or roll back
    Book* findBookMutable(int id);
    Member* findMemberMutable(int id);
    Transaction* findTransactionMutable(int id);
    bool isbnInUse(const std::string& normalizedIsbn, int exceptBookId) const;
    bool memberContactInUse(const MemberData& data, int exceptMemberId) const;

    std::string dataDirectory_;
    State state_;
    std::unordered_map<int, std::size_t> bookIndex_;
    std::unordered_map<int, std::size_t> memberIndex_;
    std::unordered_map<int, std::size_t> transactionIndex_;
};

#endif
