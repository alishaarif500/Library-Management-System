#ifndef MEMBER_H
#define MEMBER_H

#include <string>

// The editable fields of a member.
struct MemberData {
    std::string name;
    std::string phone;
    std::string email;
};

// A registered library member.
class Member {
public:
    Member() = default;
    // Throws std::invalid_argument when any value is invalid.
    Member(int id, const MemberData& data, const std::string& registrationDate);

    static void validate(const MemberData& data);  // throws std::invalid_argument

    int id() const { return id_; }
    const std::string& name() const { return name_; }
    const std::string& phone() const { return phone_; }
    const std::string& email() const { return email_; }
    const std::string& registrationDate() const { return registrationDate_; }

    void update(const MemberData& data);

private:
    int id_ = 0;
    std::string name_;
    std::string phone_;
    std::string email_;
    std::string registrationDate_;
};

#endif
