#ifndef FILE_MANAGER_H
#define FILE_MANAGER_H

#include <string>
#include <vector>

#include "Book.h"
#include "Member.h"
#include "Settings.h"
#include "Transaction.h"

// All reading and writing of data files (CSV text with quoting, plus a key=value settings file).
//
// Safety features:
//  * Files are written to "<name>.tmp" first and then renamed over the original, so a crash while
//    saving cannot leave a half-written data file.
//  * Loaders never throw for bad records: invalid lines are skipped and reported as warnings, and
//    the untouched original file is copied to "<name>.corrupt.bak" first.
class FileManager {
public:
    static const char* const kBooksHeader;
    static const char* const kMembersHeader;
    static const char* const kTransactionsHeader;

    // --- CSV primitives (public so they can be unit tested) ---
    static std::string escapeField(const std::string& field);
    // Returns false when the line is malformed (e.g. unterminated quote).
    static bool splitCsvLine(const std::string& line, std::vector<std::string>& fields);

    // --- File system helpers ---
    static void ensureDirectory(const std::string& path);   // throws std::runtime_error on failure
    static bool fileExists(const std::string& path);
    static void writeFileAtomic(const std::string& path, const std::string& content);  // throws
    static void backupFile(const std::string& path);        // copies to path + ".corrupt.bak"

    // --- Save (throw std::runtime_error when the file cannot be written) ---
    static void saveBooks(const std::string& path, const std::vector<Book>& books);
    static void saveMembers(const std::string& path, const std::vector<Member>& members);
    static void saveTransactions(const std::string& path, const std::vector<Transaction>& txs);
    static void saveSettings(const std::string& path, const Settings& settings, const IdCounters& counters);

    // --- Load (a missing file simply gives an empty result) ---
    static std::vector<Book> loadBooks(const std::string& path, std::vector<std::string>& warnings);
    static std::vector<Member> loadMembers(const std::string& path, std::vector<std::string>& warnings);
    static std::vector<Transaction> loadTransactions(const std::string& path, std::vector<std::string>& warnings);
    static void loadSettings(const std::string& path, Settings& settings, IdCounters& counters,
                             std::vector<std::string>& warnings);
};

#endif
