#ifndef TRANSACTION_H
#define TRANSACTION_H

#include <string>

// One loan of a book to a member. A transaction is "active" until the book is returned,
// after which it stays in the history with its return date and fine.
class Transaction {
public:
    Transaction() = default;
    // returnDate must be empty for an active loan. Throws std::invalid_argument if inconsistent.
    Transaction(int id, int bookId, int memberId, const std::string& issueDate,
                const std::string& dueDate, const std::string& returnDate = "",
                long long fineCents = 0);

    int id() const { return id_; }
    int bookId() const { return bookId_; }
    int memberId() const { return memberId_; }
    const std::string& issueDate() const { return issueDate_; }
    const std::string& dueDate() const { return dueDate_; }
    const std::string& returnDate() const { return returnDate_; }
    long long fineCents() const { return fineCents_; }
    bool isActive() const { return returnDate_.empty(); }

    // Closes the loan. Throws std::logic_error if already returned, std::invalid_argument if the
    // date is invalid or earlier than the issue date.
    void markReturned(const std::string& returnDate, long long fineCents);

private:
    int id_ = 0;
    int bookId_ = 0;
    int memberId_ = 0;
    std::string issueDate_;
    std::string dueDate_;
    std::string returnDate_;
    long long fineCents_ = 0;
};

#endif
