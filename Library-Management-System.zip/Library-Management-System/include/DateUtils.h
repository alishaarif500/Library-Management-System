#ifndef DATE_UTILS_H
#define DATE_UTILS_H

#include <string>

// Date helpers. All dates are text in ISO format "YYYY-MM-DD" (years 1900-2200).
namespace DateUtils {

bool isValidDate(const std::string& date);
std::string today();                                   // local system date
long toDayNumber(const std::string& date);             // days since 1970-01-01; throws std::invalid_argument
std::string addDays(const std::string& date, int days);
long daysBetween(const std::string& from, const std::string& to);  // (to - from), may be negative

}  // namespace DateUtils

#endif
