@echo off
rem Starts the Library Management System (builds it first if needed).
rem The program keeps its data in the "data\db" folder next to this script.
setlocal
cd /d "%~dp0"
if not exist build\LibraryManagementSystem.exe (
    echo Application not built yet - running build.bat ...
    call build.bat
    if errorlevel 1 exit /b 1
)
build\LibraryManagementSystem.exe %*
