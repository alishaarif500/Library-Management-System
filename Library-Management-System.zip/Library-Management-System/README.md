# Library Management System

A menu-driven **C++17 console application** for managing a small library: book inventory, members, issuing and returning books, overdue fines, reports, and permanent file-based storage. Standard library only - no database or external packages needed.

> Portfolio project demonstrating object-oriented design, file handling, STL data structures, input validation, exception handling and automated testing in modern C++.

---

## 1. Project overview

The program lets a librarian register members, catalogue books, issue and return books, calculate overdue fines and view statistics. All data is saved automatically in plain CSV files, so records survive closing and reopening the program.

## 2. Problem statement

Small libraries often track loans on paper or in loose spreadsheets. That leads to duplicate records, wrong stock counts, forgotten overdue books and lost data. This project replaces that with a small program that enforces the rules (for example "a book with no free copies cannot be issued") and always keeps stock and loan records consistent.

## 3. Objectives

- Implement complete inventory, member, issue/return and reporting workflows.
- Keep data correct: no negative stock, no double returns, no deleting a member who still has books.
- Store data permanently with safe handling of missing, empty and corrupted files.
- Use a modular architecture with clear responsibilities per class.
- Verify behaviour with an automated test suite.

## 4. Main features

| Area | Features |
|---|---|
| Books | Add, update, delete (only if no copies are issued), unique IDs, ISBN/title/author/publisher/category/year, total and available copies, duplicate-ISBN protection, sort by title or year, totals |
| Members | Register, update, delete (only with no active loans), unique IDs, name/phone/email/registration date, duplicate-email protection |
| Issue | Availability check, member check, duplicate active-loan check, automatic transaction ID, due date = issue date + loan period |
| Return | By transaction ID, double-return prevention, overdue days, fine = days x daily rate (configurable), full history |
| Search | Books by ID/title/author/ISBN/category; members by ID/name; transactions by ID |
| Reports | Titles, copies (total/available/issued), members, active/returned/overdue loans, outstanding fines, most borrowed books |
| Storage | CSV files, auto-created, validated on load, atomic saves, backup of corrupted files |
| Settings | Loan period, fine per day, optional sample data import |

## 5. Technologies used

C++17, the C++ standard library (`<vector>`, `<unordered_map>`, `<algorithm>`, `<filesystem>`, `<fstream>`, ...), CMake (optional), Windows batch scripts, GCC (MinGW-w64).

## 6. C++ concepts demonstrated

Classes and encapsulation with invariants (`Book` can never have more available than total copies), separation of concerns, RAII (file streams, test temp directories), exceptions with a custom `LibraryError`, const correctness, `std::function` and lambdas, STL containers and algorithms (`std::sort`, `std::remove_if`, `std::count_if`), dependency injection of `std::istream`/`std::ostream` for testable I/O, file I/O with CSV serialization, namespaces, and a self-written test harness.

## 7. Architecture overview

```
ConsoleUI  -->  Library  -->  FileManager  -->  files (CSV / ini)
   |               |  \--> Book, Member, Transaction (entities)
   |               \-----> DateUtils
   \--> ReportManager (read-only statistics)      InputValidator (all input checking)
```

`Library` is the only place where business rules live. `ConsoleUI` only asks questions and prints. `FileManager` only reads/writes files. Details: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md).

## 8. Project structure

```
Library-Management-System/
|-- src/            main.cpp, Book, Member, Transaction, Library, FileManager,
|                   ReportManager, InputValidator, DateUtils, ConsoleUI (.cpp)
|-- include/        matching headers + Settings.h
|-- tests/          test_main.cpp (automated tests) + README.md
|-- data/           sample_books.csv, sample_members.csv
|                   (data/db/ is created at run time and is git-ignored)
|-- docs/           FEATURES, ARCHITECTURE, TESTING, USER_GUIDE,
|                   CV_PROJECT_DESCRIPTION, GITHUB_UPLOAD
|-- CMakeLists.txt, build.bat, run.bat, .gitignore, LICENSE, README.md
```

## 9. Installation requirements

- **C++17 compiler.** Recommended: MinGW-w64 GCC **9 or newer** (for example from [MSYS2](https://www.msys2.org/) or [WinLibs](https://winlibs.com/)). MSVC (Visual Studio 2019+) also works in principle (see "Verification status" below).
- Visual Studio Code does **not** include a compiler - install one as above and make sure `g++ --version` works in a new terminal.
- Optional: CMake 3.10+.

## 10. Build instructions

Open the project folder in VS Code, open a terminal (Terminal > New Terminal) and run one of:

**Option A - batch script (simplest, Windows)**
```
build.bat
```
Creates `build\LibraryManagementSystem.exe`.

**Option B - direct GCC**
```
g++ -std=c++17 -O2 -Wall -Wextra -Iinclude src\main.cpp src\Book.cpp src\Member.cpp src\Transaction.cpp src\Library.cpp src\FileManager.cpp src\ReportManager.cpp src\InputValidator.cpp src\DateUtils.cpp src\ConsoleUI.cpp -o build\LibraryManagementSystem.exe
```
(create the `build` folder first)

**Option C - CMake**
```
cmake -S . -B build -G "MinGW Makefiles"
cmake --build build
```

## 11. Execution instructions

```
run.bat
```
or `build\LibraryManagementSystem.exe` from the project folder. Always start the program from the project folder, because data is stored relative to it (`data\db\`). Optional: `LibraryManagementSystem.exe my_data_folder` uses another data folder.

## 12. How to use

1. Start the program. Choose **8 Settings > 4 Import sample data** to load example books and members (or add your own).
2. **3 Member Management** to register members, **2 Book Inventory** to add books.
3. **4 Issue a Book**: enter a Book ID and a Member ID. Note the printed Transaction ID.
4. **5 Return a Book**: enter the Transaction ID. Late returns show overdue days and the fine.
5. **7 Reports** and **1 Dashboard** show live statistics. Choose `0` to go back or exit.

Full walkthrough: [docs/USER_GUIDE.md](docs/USER_GUIDE.md).

## 13. Testing

```
build.bat test
```
or with CMake: `cmake --build build` then `ctest --test-dir build --output-on-failure`.
The suite prints `[PASS]`/`[FAIL]` for each check and a summary. It uses temporary folders only, so your data is never touched. See [docs/TESTING.md](docs/TESTING.md) for the exact environments and results.

## 14. Screenshots

Real console output (captured from a run of the program with sample data):

```
==========================================================================================
  MAIN MENU
==========================================================================================
  1. Dashboard
  2. Book Inventory
  3. Member Management
  4. Issue a Book
  5. Return a Book
  6. Search Records
  7. Reports and Statistics
  8. Settings
  9. Help and About
  0. Exit
```

```
ID    ISBN          Title                       Author              Category      Year  Avail/Total
------------------------------------------------------------------------------------------
3     9780134610993 Artificial Intelligence: .. Stuart Russell, P.. Artificial .. 2020  1/2
1     9780132350884 Clean Code                  Robert C. Martin    Software En.. 2008  3/3
8     9780078022159 Database System Concepts    Silberschatz, Kor.. Databases     2019  3/3
```

**Screenshot placeholders** (add your own after running the program on your computer, save them in `docs/screenshots/`):

- `[PLACEHOLDER: docs/screenshots/main-menu.png - main menu]`
- `[PLACEHOLDER: docs/screenshots/dashboard.png - dashboard with statistics]`
- `[PLACEHOLDER: docs/screenshots/issue-return.png - issuing and returning a book with fine]`

## 15. Verification status (honest summary)

- Automated tests: 224 checks, all passing on Linux (GCC 13.3, also with AddressSanitizer + UndefinedBehaviorSanitizer) and as a Windows executable (MinGW-w64 GCC 13) run under Wine.
- **Not yet verified on a real Windows 10/11 machine**: `build.bat`, `run.bat` and the MSVC build were written carefully but could not be executed in the development environment. See [docs/TESTING.md](docs/TESTING.md).

## 16. Limitations and future improvements

Limitations: single user at a time (no file locking), no login/roles, no per-member loan limit, fines are calculated and recorded but payment tracking is not implemented, ISBN check digits are not verified, whole files are rewritten on every change (fine for thousands of records, not for very large libraries), text limits are measured in bytes, and accented characters may need `chcp 65001` to display correctly in the Windows console.

Possible improvements: SQLite storage, renewals and reservations, member loan limits, fine payment records, a graphical or web interface, CSV/PDF report export, unit-test framework such as Catch2/GoogleTest, and continuous integration on GitHub Actions.

## 17. Author

**[Your Name]** - [your email or LinkedIn] - [your university / city]

Licensed under the MIT License (see [LICENSE](LICENSE)). Sample books are illustrative; publication details in the sample files may not be bibliographically exact.
