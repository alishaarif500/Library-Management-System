@echo off
rem ============================================================================
rem  Build script for Windows.
rem    build.bat          builds the application   -> build\LibraryManagementSystem.exe
rem    build.bat test     builds and runs the automated tests
rem  Requires g++ (MinGW-w64, GCC 9 or newer) on PATH, or the MSVC compiler (cl)
rem  inside a "Developer Command Prompt for VS".
rem ============================================================================
setlocal
cd /d "%~dp0"
if not exist build mkdir build

set CORE=src\Book.cpp src\Member.cpp src\Transaction.cpp src\Library.cpp src\FileManager.cpp src\ReportManager.cpp src\InputValidator.cpp src\DateUtils.cpp src\ConsoleUI.cpp

where g++ >nul 2>nul
if %errorlevel%==0 goto :use_gcc
where cl >nul 2>nul
if %errorlevel%==0 goto :use_msvc

echo ERROR: No C++ compiler found.
echo Install MinGW-w64 / MSYS2 (g++ 9 or newer) and add its "bin" folder to PATH,
echo or run this script from a "Developer Command Prompt for VS".
exit /b 1

:use_gcc
set FLAGS=-std=c++17 -O2 -Wall -Wextra -Wpedantic -Iinclude
if /I "%1"=="test" goto :gcc_test
echo Building application with g++ ...
g++ %FLAGS% src\main.cpp %CORE% -o build\LibraryManagementSystem.exe
if errorlevel 1 goto :failed
echo Build successful: build\LibraryManagementSystem.exe
exit /b 0

:gcc_test
echo Building tests with g++ ...
g++ %FLAGS% tests\test_main.cpp %CORE% -o build\lms_tests.exe
if errorlevel 1 goto :failed
build\lms_tests.exe
exit /b %errorlevel%

:use_msvc
set FLAGS=/nologo /std:c++17 /EHsc /W4 /utf-8 /Iinclude
if /I "%1"=="test" goto :msvc_test
echo Building application with MSVC ...
cl %FLAGS% src\main.cpp %CORE% /Fo:build\ /Fe:build\LibraryManagementSystem.exe
if errorlevel 1 goto :failed
echo Build successful: build\LibraryManagementSystem.exe
exit /b 0

:msvc_test
echo Building tests with MSVC ...
cl %FLAGS% tests\test_main.cpp %CORE% /Fo:build\ /Fe:build\lms_tests.exe
if errorlevel 1 goto :failed
build\lms_tests.exe
exit /b %errorlevel%

:failed
echo.
echo BUILD FAILED. See the compiler messages above.
exit /b 1
